# Sentinel Rx — PBM Compliance Review Dashboard

A React + Material UI dashboard for reviewing a PBM contract against a
regulatory reference document. No backend is wired up yet — the "review"
is generated client-side so the UI can be built and demoed end to end.

## Project structure

```
sentinel-rx/
├─ index.html
├─ vite.config.js
├─ package.json
└─ src/
   ├─ main.jsx              # React root, MUI ThemeProvider
   ├─ App.jsx                # Layout: sidebar + top bar + active page
   ├─ theme.js                # MUI theme (palette, typography, risk colors)
   ├─ data/
   │  ├─ catalog.js           # Dropdown options (contracts, regulations, categories)
   │  └─ generateAnalysis.js  # Mock "LLM" output generator — swap for a real API call
   ├─ hooks/
   │  └─ useComplianceAnalysis.js  # useEffect-based fetch simulation
   ├─ components/
   │  ├─ Sidebar.jsx
   │  ├─ TopBar.jsx
   │  ├─ DocSelector.jsx      # dropdown OR file upload, per document
   │  ├─ KpiCard.jsx
   │  ├─ RiskBadge.jsx
   │  └─ charts/
   │     ├─ RiskDonutChart.jsx
   │     ├─ CategoryBarChart.jsx
   │     └─ TrendLineChart.jsx
   └─ pages/
      ├─ Overview.jsx         # Tab 1: KPI cards + charts
      └─ ViolationLog.jsx     # Tab 2: filterable findings table
```

## Run it

```bash
npm install
npm run dev
```

Then open the URL Vite prints (usually `http://localhost:5173`).

## How the data flows

1. `App.jsx` holds the selected contract/reference (dropdown value or an
   uploaded file name) and a `runNonce` counter.
2. `useComplianceAnalysis` runs a `useEffect` keyed on `runNonce`. It
   currently fakes network latency with `setTimeout` and calls
   `generateAnalysis()` to produce a result shaped like a real API
   response.
3. Clicking **Run Review** bumps `runNonce`, which re-triggers the effect
   — this is the seam where a real backend call plugs in.

## Wiring up a real backend later

Replace the body of the `useEffect` in `src/hooks/useComplianceAnalysis.js`
with something like:

```js
fetch("/api/analyze", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ contractDoc: contractLabel, referenceDoc: referenceLabel }),
})
  .then((res) => res.json())
  .then((data) => { setAnalysis(data); setIsAnalyzing(false); });
```

As long as the response has the same shape as `generateAnalysis()` returns
(`totalClauses`, `violations[]`, `riskCounts`, `categoryBreakdown`,
`complianceScore`, `trend`, `timestamp`), nothing else in the app needs to
change.

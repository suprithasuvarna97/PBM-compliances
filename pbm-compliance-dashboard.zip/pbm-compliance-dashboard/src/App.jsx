import { useRef, useState } from "react";
import Box from "@mui/material/Box";
import CircularProgress from "@mui/material/CircularProgress";
import Typography from "@mui/material/Typography";
import Sidebar, { SIDEBAR_WIDTH } from "./components/Sidebar";
import TopBar from "./components/TopBar";
import Overview from "./pages/Overview";
import ViolationLog from "./pages/ViolationLog";
import { CONTRACT_DOCS, REFERENCE_DOCS } from "./data/catalog";
import { useComplianceAnalysis } from "./hooks/useComplianceAnalysis";

export default function App() {
  const [activeTab, setActiveTab] = useState("overview");

  const [contractDoc, setContractDoc] = useState(CONTRACT_DOCS[0]);
  const [referenceDoc, setReferenceDoc] = useState(REFERENCE_DOCS[0]);
  const [contractFile, setContractFile] = useState(null);
  const [referenceFile, setReferenceFile] = useState(null);
  const [runNonce, setRunNonce] = useState(0);

  const contractLabel = contractFile || contractDoc;
  const referenceLabel = referenceFile || referenceDoc;

  const { isAnalyzing, analysis } = useComplianceAnalysis({
    contractLabel,
    referenceLabel,
    runNonce,
  });

  return (
    <Box sx={{ display: "flex", minHeight: "100vh", bgcolor: "background.default" }}>
      <Sidebar activeTab={activeTab} onChangeTab={setActiveTab} />

      <Box sx={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
        <TopBar
          title={activeTab === "overview" ? "Compliance Overview" : "Violation Log"}
          subtitle="Select the contract and the regulatory reference to evaluate"
          contractDoc={contractDoc}
          setContractDoc={setContractDoc}
          contractFile={contractFile}
          setContractFile={setContractFile}
          referenceDoc={referenceDoc}
          setReferenceDoc={setReferenceDoc}
          referenceFile={referenceFile}
          setReferenceFile={setReferenceFile}
          isAnalyzing={isAnalyzing}
          onRun={() => setRunNonce((n) => n + 1)}
        />

        <Box sx={{ p: "24px 28px 40px", flex: 1 }}>
          {isAnalyzing || !analysis ? (
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: 1.25,
                py: 10,
                color: "text.secondary",
              }}
            >
              <CircularProgress size={26} thickness={4} />
              <Typography sx={{ fontSize: 13 }}>
                Reviewing clauses against the selected regulatory reference…
              </Typography>
            </Box>
          ) : activeTab === "overview" ? (
            <Overview analysis={analysis} contractLabel={contractLabel} referenceLabel={referenceLabel} />
          ) : (
            <ViolationLog analysis={analysis} />
          )}
        </Box>
      </Box>
    </Box>
  );
}

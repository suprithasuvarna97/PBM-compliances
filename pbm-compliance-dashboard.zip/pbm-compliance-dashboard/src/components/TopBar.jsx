import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import CircularProgress from "@mui/material/CircularProgress";
import PlayArrowRoundedIcon from "@mui/icons-material/PlayArrowRounded";
import DocSelector from "./DocSelector";
import { CONTRACT_DOCS, REFERENCE_DOCS } from "../data/catalog";

export default function TopBar({
  title,
  subtitle,
  contractDoc,
  setContractDoc,
  contractFile,
  setContractFile,
  referenceDoc,
  setReferenceDoc,
  referenceFile,
  setReferenceFile,
  isAnalyzing,
  onRun,
}) {
  return (
    <Box
      sx={{
        bgcolor: "background.paper",
        borderBottom: "1px solid",
        borderColor: "divider",
        px: 3.5,
        py: 2,
        display: "flex",
        alignItems: "flex-end",
        justifyContent: "space-between",
        gap: 2.5,
        flexWrap: "wrap",
      }}
    >
      <Box>
        <Typography variant="h5" sx={{ fontSize: 21, mb: 0.2 }}>
          {title}
        </Typography>
        <Typography sx={{ fontSize: 12.5, color: "text.secondary" }}>{subtitle}</Typography>
      </Box>

      <Box sx={{ display: "flex", gap: 1.75, alignItems: "flex-end", flexWrap: "wrap" }}>
        <DocSelector
          label="Contract document"
          options={CONTRACT_DOCS}
          value={contractDoc}
          onChange={setContractDoc}
          fileName={contractFile}
          onFile={setContractFile}
          onClearFile={() => setContractFile(null)}
        />
        <DocSelector
          label="Regulatory reference"
          options={REFERENCE_DOCS}
          value={referenceDoc}
          onChange={setReferenceDoc}
          fileName={referenceFile}
          onFile={setReferenceFile}
          onClearFile={() => setReferenceFile(null)}
        />
        <Button
          variant="contained"
          disableElevation
          disabled={isAnalyzing}
          onClick={onRun}
          startIcon={
            isAnalyzing ? <CircularProgress size={14} color="inherit" /> : <PlayArrowRoundedIcon sx={{ fontSize: 18 }} />
          }
          sx={{ bgcolor: "#1B2233", "&:hover": { bgcolor: "#2A3450" }, px: 2, py: 1.1, fontSize: 13 }}
        >
          {isAnalyzing ? "Reviewing…" : "Run Review"}
        </Button>
      </Box>
    </Box>
  );
}

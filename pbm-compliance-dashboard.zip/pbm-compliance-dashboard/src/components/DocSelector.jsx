import { useRef } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import IconButton from "@mui/material/IconButton";
import Chip from "@mui/material/Chip";
import UploadFileRoundedIcon from "@mui/icons-material/UploadFileRounded";
import InsertDriveFileRoundedIcon from "@mui/icons-material/InsertDriveFileRounded";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import Tooltip from "@mui/material/Tooltip";

export default function DocSelector({ label, options, value, onChange, fileName, onFile, onClearFile }) {
  const inputRef = useRef(null);

  return (
    <Box sx={{ display: "flex", flexDirection: "column", gap: 0.6, minWidth: 260 }}>
      <Typography sx={{ fontSize: 11, color: "text.secondary" }}>{label}</Typography>
      <Box sx={{ display: "flex", alignItems: "center", gap: 0.75 }}>
        {fileName ? (
          <Chip
            icon={<InsertDriveFileRoundedIcon sx={{ fontSize: 15 }} />}
            label={fileName}
            onDelete={onClearFile}
            deleteIcon={<CloseRoundedIcon sx={{ fontSize: 14 }} />}
            sx={{
              flex: 1,
              justifyContent: "flex-start",
              bgcolor: "#E7EEF5",
              color: "primary.main",
              maxWidth: 260,
              "& .MuiChip-label": { overflow: "hidden", textOverflow: "ellipsis" },
            }}
          />
        ) : (
          <FormControl size="small" sx={{ flex: 1 }}>
            <Select
              value={value}
              onChange={(e) => onChange(e.target.value)}
              sx={{
                fontSize: 12.5,
                bgcolor: "#FAFBFC",
                "& .MuiOutlinedInput-notchedOutline": { borderColor: "divider" },
              }}
            >
              {options.map((o) => (
                <MenuItem key={o} value={o} sx={{ fontSize: 12.5 }}>
                  {o}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        )}

        <Tooltip title="Upload a document instead">
          <IconButton
            size="small"
            onClick={() => inputRef.current?.click()}
            sx={{
              bgcolor: "#E7EEF5",
              color: "primary.main",
              borderRadius: "6px",
              border: "1px solid #D3E1EE",
              "&:hover": { bgcolor: "#DCE8F3" },
            }}
          >
            <UploadFileRoundedIcon sx={{ fontSize: 17 }} />
          </IconButton>
        </Tooltip>
        <input
          ref={inputRef}
          type="file"
          accept=".pdf,.doc,.docx,.txt"
          hidden
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) onFile(f.name);
          }}
        />
      </Box>
    </Box>
  );
}

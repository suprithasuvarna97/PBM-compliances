import { createTheme } from "@mui/material/styles";

// Design tokens for the compliance/audit look: steel-blue accent,
// muted risk colors, serif headings for a "report" feel.
const theme = createTheme({
  palette: {
    mode: "light",
    background: { default: "#F3F4F7", paper: "#FFFFFF" },
    primary: { main: "#2F5D8C" },
    text: { primary: "#1B2233", secondary: "#5B6472" },
    divider: "#E1E4EA",
  },
  // Custom palette extension for risk levels — accessed as
  // theme.riskColors.high / .moderate / .low throughout the app.
  riskColors: {
    high: { fg: "#8A2E1F", bg: "#F6E4DF", dot: "#B3432F" },
    moderate: { fg: "#7A5417", bg: "#F5EAD7", dot: "#B8842E" },
    low: { fg: "#2C5A41", bg: "#DEEAE2", dot: "#3C7A5C" },
  },
  shape: { borderRadius: 8 },
  typography: {
    fontFamily: "'IBM Plex Sans', sans-serif",
    h1: { fontFamily: "'Source Serif 4', serif" },
    h2: { fontFamily: "'Source Serif 4', serif" },
    h3: { fontFamily: "'Source Serif 4', serif" },
    h4: { fontFamily: "'Source Serif 4', serif", fontWeight: 600 },
    h5: { fontFamily: "'Source Serif 4', serif", fontWeight: 600 },
    h6: { fontFamily: "'Source Serif 4', serif", fontWeight: 600 },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: { textTransform: "none", fontWeight: 500, borderRadius: 7 },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: { fontWeight: 500 },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: { backgroundImage: "none" },
      },
    },
  },
});

export default theme;

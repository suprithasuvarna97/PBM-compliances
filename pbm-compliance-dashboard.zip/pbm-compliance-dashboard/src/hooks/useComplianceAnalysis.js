import { useEffect, useState } from "react";
import { generateAnalysis } from "../data/generateAnalysis";

// Simulates calling the review API. `runNonce` is bumped by the "Run
// Review" button to trigger a fresh call; contractLabel/referenceLabel
// are read at call time via closure, same as a real fetch would read
// current form state when the request fires.
export function useComplianceAnalysis({ contractLabel, referenceLabel, runNonce }) {
  const [isAnalyzing, setIsAnalyzing] = useState(true);
  const [analysis, setAnalysis] = useState(null);

  useEffect(() => {
    let cancelled = false;
    setIsAnalyzing(true);

    // --- Replace this block with a real API call, e.g.: -----------------
    // fetch("/api/analyze", {
    //   method: "POST",
    //   headers: { "Content-Type": "application/json" },
    //   body: JSON.stringify({ contractDoc: contractLabel, referenceDoc: referenceLabel }),
    // })
    //   .then((res) => res.json())
    //   .then((data) => { if (!cancelled) { setAnalysis(data); setIsAnalyzing(false); } });
    // ---------------------------------------------------------------------
    const timer = setTimeout(() => {
      if (cancelled) return;
      const result = generateAnalysis(contractLabel, referenceLabel, runNonce);
      setAnalysis(result);
      setIsAnalyzing(false);
    }, 1100);

    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runNonce]);

  return { isAnalyzing, analysis };
}

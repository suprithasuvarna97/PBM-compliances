import { useMemo, useState } from "react";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableCell from "@mui/material/TableCell";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";
import ToggleButton from "@mui/material/ToggleButton";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";
import Typography from "@mui/material/Typography";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import RiskBadge from "../components/RiskBadge";

const RISK_LEVELS = ["All", "High", "Moderate", "Low"];

export default function ViolationLog({ analysis }) {
  const [riskFilter, setRiskFilter] = useState("All");
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    return analysis.violations.filter((v) => {
      const matchesRisk = riskFilter === "All" || v.risk === riskFilter;
      const q = query.trim().toLowerCase();
      const matchesQuery =
        !q ||
        v.id.toLowerCase().includes(q) ||
        v.category.toLowerCase().includes(q) ||
        v.description.toLowerCase().includes(q);
      return matchesRisk && matchesQuery;
    });
  }, [analysis, riskFilter, query]);

  return (
    <Box>
      <Box sx={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 1.5, mb: 1.75 }}>
        <ToggleButtonGroup
          exclusive
          size="small"
          value={riskFilter}
          onChange={(e, val) => val && setRiskFilter(val)}
        >
          {RISK_LEVELS.map((lvl) => (
            <ToggleButton key={lvl} value={lvl} sx={{ textTransform: "none", fontSize: 12.5, px: 1.75 }}>
              {lvl}
            </ToggleButton>
          ))}
        </ToggleButtonGroup>

        <TextField
          size="small"
          placeholder="Search rule ID, category, or description"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          sx={{ minWidth: 280, bgcolor: "background.paper" }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchRoundedIcon sx={{ fontSize: 18, color: "#8992A1" }} />
              </InputAdornment>
            ),
          }}
        />
      </Box>

      <TableContainer component={Paper} variant="outlined">
        <Table size="small">
          <TableHead>
            <TableRow sx={{ "& th": { bgcolor: "#FAFBFC", fontSize: 11, color: "text.secondary", fontWeight: 500 } }}>
              <TableCell>Rule ID</TableCell>
              <TableCell>Category</TableCell>
              <TableCell>Contract Clause</TableCell>
              <TableCell>Regulatory Reference</TableCell>
              <TableCell>Risk</TableCell>
              <TableCell>Finding</TableCell>
              <TableCell>Recommended Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} align="center" sx={{ py: 5, color: "#8992A1" }}>
                  No findings match the current filter.
                </TableCell>
              </TableRow>
            ) : (
              filtered.map((v) => (
                <TableRow key={v.id} hover>
                  <TableCell sx={{ fontWeight: 500, whiteSpace: "nowrap" }}>{v.id}</TableCell>
                  <TableCell sx={{ fontSize: 12.5 }}>{v.category}</TableCell>
                  <TableCell sx={{ fontSize: 12.5, color: "text.secondary", whiteSpace: "nowrap" }}>
                    {v.clause}
                  </TableCell>
                  <TableCell sx={{ fontSize: 12.5, color: "text.secondary", whiteSpace: "nowrap" }}>
                    {v.regClause}
                  </TableCell>
                  <TableCell>
                    <RiskBadge level={v.risk} />
                  </TableCell>
                  <TableCell sx={{ fontSize: 12.5, maxWidth: 300, lineHeight: 1.45 }}>{v.description}</TableCell>
                  <TableCell sx={{ fontSize: 12.5, maxWidth: 260, lineHeight: 1.45, color: "text.secondary" }}>
                    {v.recommendation}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {filtered.length > 0 && (
        <Typography sx={{ fontSize: 11.5, color: "#8992A1", mt: 1.25 }}>
          Showing {filtered.length} of {analysis.violations.length} findings
        </Typography>
      )}
    </Box>
  );
}

import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
import AccessTimeRoundedIcon from "@mui/icons-material/AccessTimeRounded";
import ChecklistRtlRoundedIcon from "@mui/icons-material/ChecklistRtlRounded";
import ReportProblemRoundedIcon from "@mui/icons-material/ReportProblemRounded";
import SpeedRoundedIcon from "@mui/icons-material/SpeedRounded";
import ArrowUpwardRoundedIcon from "@mui/icons-material/ArrowUpwardRounded";
import ArrowDownwardRoundedIcon from "@mui/icons-material/ArrowDownwardRounded";
import KpiCard from "../components/KpiCard";
import RiskDonutChart from "../components/charts/RiskDonutChart";
import CategoryBarChart from "../components/charts/CategoryBarChart";
import TrendLineChart from "../components/charts/TrendLineChart";

export default function Overview({ analysis, contractLabel, referenceLabel }) {
  const prevScore = analysis.trend[analysis.trend.length - 2]?.score;
  const scoreDelta = prevScore != null ? analysis.complianceScore - prevScore : 0;

  return (
    <Box>
      <Box sx={{ display: "flex", alignItems: "center", gap: 0.75, fontSize: 11.5, color: "#8992A1", mb: 2 }}>
        <AccessTimeRoundedIcon sx={{ fontSize: 15 }} />
        Last reviewed {analysis.timestamp} · {contractLabel} against {referenceLabel}
      </Box>

      <Grid container spacing={1.75} sx={{ mb: 2 }}>
        <Grid item xs={12} sm={6} md={3}>
          <KpiCard
            icon={<ChecklistRtlRoundedIcon sx={{ fontSize: 18 }} />}
            label="Clauses Evaluated"
            value={analysis.totalClauses}
            sub="across the submitted contract"
            tone="#2F5D8C"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <KpiCard
            icon={<ReportProblemRoundedIcon sx={{ fontSize: 18 }} />}
            label="Rules Broken"
            value={analysis.violations.length}
            sub={`${analysis.categoryBreakdown.length} categories affected`}
            tone="#B8842E"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <KpiCard
            icon={<ReportProblemRoundedIcon sx={{ fontSize: 18 }} />}
            label="High Risk Findings"
            value={analysis.riskCounts.High}
            sub="require immediate remediation"
            tone="#B3432F"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <KpiCard
            icon={<SpeedRoundedIcon sx={{ fontSize: 18 }} />}
            label="Compliance Score"
            value={`${analysis.complianceScore}%`}
            sub={
              <>
                {scoreDelta >= 0 ? (
                  <ArrowUpwardRoundedIcon sx={{ fontSize: 13 }} />
                ) : (
                  <ArrowDownwardRoundedIcon sx={{ fontSize: 13 }} />
                )}
                {Math.abs(scoreDelta)} pts vs prior cycle
              </>
            }
            tone="#3C7A5C"
          />
        </Grid>
      </Grid>

      <Grid container spacing={1.75} sx={{ mb: 1.75 }}>
        <Grid item xs={12} md={5}>
          <Paper variant="outlined" sx={{ p: "16px 18px 8px", height: "100%" }}>
            <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", mb: 0.75 }}>
              <Typography variant="h6" sx={{ fontSize: 15 }}>
                Risk Distribution
              </Typography>
              <Typography sx={{ fontSize: 11.5, color: "#8992A1" }}>by finding</Typography>
            </Box>
            <RiskDonutChart riskCounts={analysis.riskCounts} />
          </Paper>
        </Grid>
        <Grid item xs={12} md={7}>
          <Paper variant="outlined" sx={{ p: "16px 18px 8px", height: "100%" }}>
            <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", mb: 0.75 }}>
              <Typography variant="h6" sx={{ fontSize: 15 }}>
                Violations by Category
              </Typography>
              <Typography sx={{ fontSize: 11.5, color: "#8992A1" }}>count of findings</Typography>
            </Box>
            <CategoryBarChart data={analysis.categoryBreakdown} />
          </Paper>
        </Grid>
      </Grid>

      <Paper variant="outlined" sx={{ p: "16px 18px 8px" }}>
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", mb: 0.75 }}>
          <Typography variant="h6" sx={{ fontSize: 15 }}>
            Compliance Score Trend
          </Typography>
          <Typography sx={{ fontSize: 11.5, color: "#8992A1" }}>last 6 review cycles</Typography>
        </Box>
        <TrendLineChart data={analysis.trend} />
      </Paper>
    </Box>
  );
}

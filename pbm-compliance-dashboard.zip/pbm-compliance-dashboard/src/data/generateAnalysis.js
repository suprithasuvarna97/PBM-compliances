import { CATEGORIES, TEMPLATES } from "./catalog";

// Deterministic-ish PRNG seeded from a string, so a given document pair
// returns a stable result set until the user explicitly re-runs review.
function hashSeed(str) {
  let h = 1779033703 ^ str.length;
  for (let i = 0; i < str.length; i++) {
    h = Math.imul(h ^ str.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return () => {
    h = Math.imul(h ^ (h >>> 16), 2246822507);
    h = Math.imul(h ^ (h >>> 13), 3266489909);
    h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
  };
}

// Stand-in for a real backend call:
//   POST /api/analyze { contractDoc, referenceDoc } -> AnalysisResult
// Replace the body of this function with a fetch() once the endpoint exists;
// keep the same return shape and every component below keeps working.
export function generateAnalysis(contractDoc, referenceDoc, nonce = 0) {
  const rand = hashSeed(`${contractDoc}::${referenceDoc}::${nonce}`);
  const totalClauses = 70 + Math.floor(rand() * 70);

  const violations = [];
  let counter = 1;
  CATEGORIES.forEach((cat) => {
    const templates = TEMPLATES[cat.code];
    const numForCat = rand() < 0.78 ? 1 + Math.floor(rand() * templates.length) : 0;
    for (let i = 0; i < numForCat; i++) {
      const tpl = templates[i % templates.length];
      const riskRoll = rand();
      const risk = riskRoll < 0.28 ? "High" : riskRoll < 0.66 ? "Moderate" : "Low";
      violations.push({
        id: `PBM-${cat.code}-${String(100 + counter).padStart(3, "0")}`,
        category: cat.name,
        clause: `Section ${1 + Math.floor(rand() * 9)}.${1 + Math.floor(rand() * 8)}(${String.fromCharCode(
          97 + Math.floor(rand() * 5)
        )})`,
        regClause: referenceDoc.split("(")[0].trim(),
        risk,
        description: tpl.d,
        recommendation: tpl.r,
      });
      counter++;
    }
  });

  const riskOrder = { High: 0, Moderate: 1, Low: 2 };
  violations.sort((a, b) => riskOrder[a.risk] - riskOrder[b.risk]);

  const riskCounts = { High: 0, Moderate: 0, Low: 0 };
  violations.forEach((v) => riskCounts[v.risk]++);

  const categoryBreakdown = CATEGORIES.map((c) => ({
    name: c.name.split(" ")[0],
    fullName: c.name,
    count: violations.filter((v) => v.category === c.name).length,
  })).filter((c) => c.count > 0);

  const penalty = riskCounts.High * 6 + riskCounts.Moderate * 2.5 + riskCounts.Low * 0.8;
  const complianceScore = Math.max(38, Math.round(100 - penalty));

  const trend = [];
  let running = Math.min(96, complianceScore + 14 + Math.floor(rand() * 10));
  for (let i = 5; i >= 1; i--) {
    running = Math.max(40, running - Math.floor(rand() * 7));
    trend.push({ cycle: `Audit Q${((6 - i) % 4) + 1}`, score: running });
  }
  trend.push({ cycle: "Current", score: complianceScore });

  return {
    totalClauses,
    violations,
    riskCounts,
    categoryBreakdown,
    complianceScore,
    trend,
    timestamp: new Date().toLocaleString("en-US", {
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit",
    }),
  };
}

// Static reference catalog — in the real system these lists would come
// from a documents/regulations API instead of being hardcoded.

export const CONTRACT_DOCS = [
  "Meridian Health — PBM Master Services Agreement (FY26)",
  "Horizon Rx Network — Pharmacy Services Contract",
  "Statewide Medicaid PBM Agreement — Dept. of Health & Human Services",
  "Acme Industries — Employer Group Rx Benefit Contract",
];

export const REFERENCE_DOCS = [
  "CMS Medicare Part D Regulations (42 CFR § 423)",
  "ERISA Fiduciary Duty Standards (29 U.S.C. § 1104)",
  "NCPDP Telecommunication & SCRIPT Standards",
  "State PBM Licensing & Transparency Act",
  "340B Drug Pricing Program Rules (42 U.S.C. § 256b)",
];

export const CATEGORIES = [
  { code: "REB", name: "Rebate Pass-Through & Aggregation" },
  { code: "FOR", name: "Formulary Placement & Management" },
  { code: "NET", name: "Network Adequacy & Pharmacy Access" },
  { code: "PRV", name: "Data Privacy & Security" },
  { code: "PRC", name: "Pricing & Spread Transparency" },
  { code: "CLM", name: "Claims Adjudication Accuracy" },
  { code: "RPT", name: "Reporting & Disclosure Obligations" },
  { code: "AUD", name: "Audit & Inspection Rights" },
];

export const TEMPLATES = {
  REB: [
    {
      d: "Manufacturer rebate share owed to plan sponsor is not passed through within the contractual settlement window.",
      r: "Amend Section 4 to define a fixed rebate remittance schedule tied to quarter-end close.",
    },
    {
      d: "Aggregated rebate revenue is reported at the book-of-business level rather than per-plan, obscuring sponsor-level entitlement.",
      r: "Require per-plan rebate ledgers reconciled against manufacturer remittance statements.",
    },
  ],
  FOR: [
    {
      d: "Formulary tier placement favors rebate-generating brand products over lower net-cost generics for the same indication.",
      r: "Introduce a net-cost review step before any tier placement change takes effect.",
    },
    {
      d: "P&T committee formulary decisions are not documented with clinical rationale as required.",
      r: "Mandate meeting minutes and written rationale for every formulary determination.",
    },
  ],
  NET: [
    {
      d: "Rural service area pharmacy density falls below the minimum access standard for maintenance medications.",
      r: "Add network adequacy reporting by ZIP code with a remediation trigger below threshold.",
    },
  ],
  PRV: [
    {
      d: "Claims data sharing with an affiliated analytics entity lacks a documented minimum-necessary determination.",
      r: "Execute a data use agreement scoping fields to the minimum necessary for the stated purpose.",
    },
    {
      d: "Member PHI retention period exceeds the limit specified in the reference standard without a documented exception.",
      r: "Align retention schedule to policy and log any exception with an expiration date.",
    },
  ],
  PRC: [
    {
      d: "Spread pricing between pharmacy reimbursement and plan sponsor billing is not disclosed in the quarterly reporting package.",
      r: "Add a spread disclosure line item broken out by drug class in every reporting cycle.",
    },
  ],
  CLM: [
    {
      d: "A sample of adjudicated claims shows copay calculated against list price rather than the contracted discounted rate.",
      r: "Re-run affected claims through the correct pricing table and issue member refunds where owed.",
    },
  ],
  RPT: [
    {
      d: "Annual transparency report omits generic dispensing rate broken out by channel as required.",
      r: "Extend the reporting template to include channel-level generic dispensing metrics.",
    },
    {
      d: "Reporting cadence in practice runs 45 days behind the contractual submission deadline.",
      r: "Automate report generation from the claims warehouse to close the timing gap.",
    },
  ],
  AUD: [
    {
      d: "Contract limits sponsor audit scope to a 12-month lookback despite a 3-year record retention obligation.",
      r: "Extend audit lookback rights to match the retention period stated in the reference standard.",
    },
  ],
};

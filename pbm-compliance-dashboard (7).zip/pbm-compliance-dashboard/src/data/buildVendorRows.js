import { getVendorMeta } from "./catalog";

// Builds one Vendor View row per contract, aggregating that contract's
// results across every currently selected regulation. Reads from the same
// matrix Overview and Violation Log use, so numbers always match exactly
// for the same contract.
export function buildVendorRows(vendorContracts, regulations, matrix) {
  return vendorContracts.map((contract) => {
    const meta = getVendorMeta(contract.label);
    const perRegulation = matrix[contract.id] || {};
    const results = regulations.map((r) => perRegulation[r.id]).filter(Boolean);

    const findings = { High: 0, Moderate: 0, Low: 0 };
    let scoreSum = 0;
    results.forEach((result) => {
      findings.High += result.riskCounts.High;
      findings.Moderate += result.riskCounts.Moderate;
      findings.Low += result.riskCounts.Low;
      scoreSum += result.complianceScore;
    });

    const reviewed = results.length > 0;
    const complianceScore = reviewed ? Math.round(scoreSum / results.length) : null;
    const risk = !reviewed ? null : findings.High > 0 ? "High" : findings.Moderate > 0 ? "Moderate" : "Low";

    return {
      id: contract.id,
      vendorName: meta.vendor,
      contractLabel: contract.label,
      department: meta.department,
      risk,
      complianceScore,
      findings,
      reviewed,
    };
  });
}

// Static reference catalog — in the real system these lists would come
// from a documents/regulations API instead of being hardcoded.

export const CONTRACT_DOCS = [
  "Meridian Health — PBM Master Services Agreement (FY26)",
  "Horizon Rx Network — Pharmacy Services Contract",
  "Statewide Medicaid PBM Agreement — Dept. of Health & Human Services",
  "Acme Industries — Employer Group Rx Benefit Contract",
];

export const REFERENCE_DOCS = [
  "CMS Medicare Part D Regulations (42 CFR § 423)",
  "ERISA Fiduciary Duty Standards (29 U.S.C. § 1104)",
  "NCPDP Telecommunication & SCRIPT Standards",
  "State PBM Licensing & Transparency Act",
  "340B Drug Pricing Program Rules (42 U.S.C. § 256b)",
];

// Public source for each catalog regulation's own text — used by
// UploadsDialog's "Source" link (separate from the impact-evidence links
// below). Uploaded documents won't have an entry here on purpose.
export const REFERENCE_LINKS = {
  "CMS Medicare Part D Regulations (42 CFR § 423)":
    "https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-B/part-423",
  "ERISA Fiduciary Duty Standards (29 U.S.C. § 1104)":
    "https://www.law.cornell.edu/uscode/text/29/1104",
  "NCPDP Telecommunication & SCRIPT Standards": "https://standards.ncpdp.org/",
  "State PBM Licensing & Transparency Act":
    "https://www.ncsl.org/health/pharmacy-benefit-managers",
  "340B Drug Pricing Program Rules (42 U.S.C. § 256b)": "https://www.hrsa.gov/opa",
};

export const CATEGORIES = [
  { code: "REB", name: "Rebate Pass-Through & Aggregation" },
  { code: "FOR", name: "Formulary Placement & Management" },
  { code: "NET", name: "Network Adequacy & Pharmacy Access" },
  { code: "PRV", name: "Data Privacy & Security" },
  { code: "PRC", name: "Pricing & Spread Transparency" },
  { code: "CLM", name: "Claims Adjudication Accuracy" },
  { code: "RPT", name: "Reporting & Disclosure Obligations" },
  { code: "AUD", name: "Audit & Inspection Rights" },
];

// Vendor metadata for each catalog contract — used by the Vendor View tab
// to show a proper vendor name and owning department instead of the raw
// contract title. Uploaded contracts won't have an entry here on purpose;
// getVendorMeta() falls back to something reasonable for those.
export const VENDOR_META = {
  "Meridian Health — PBM Master Services Agreement (FY26)": {
    vendor: "Meridian Health",
    department: "Pharmacy Operations",
  },
  "Horizon Rx Network — Pharmacy Services Contract": {
    vendor: "Horizon Rx Network",
    department: "Network Management",
  },
  "Statewide Medicaid PBM Agreement — Dept. of Health & Human Services": {
    vendor: "State DHHS Medicaid Program",
    department: "Government Programs",
  },
  "Acme Industries — Employer Group Rx Benefit Contract": {
    vendor: "Acme Industries",
    department: "Employer Benefits",
  },
};

export function getVendorMeta(contractLabel) {
  return VENDOR_META[contractLabel] || { vendor: contractLabel.replace(/\.[^/.]+$/, ""), department: "Unassigned" };
}

// Real, verified public pages that document actual regulatory consequences
// for each category of violation (enforcement actions, penalty structures,
// audit findings) — this is what backs the "Impact Analysis" column's
// link. Deliberately a DIFFERENT source than REFERENCE_LINKS above: that
// one is the regulation's own text; this is evidence of what actually
// happens when this kind of gap goes unresolved. Several categories share
// a page on purpose — CMS's compliance-actions page, for example, covers
// enforcement across several of these violation types.
export const IMPACT_LINKS = {
  REB: "https://www.cms.gov/Medicare/Compliance-and-Audits/Part-C-and-Part-D-Compliance-and-Audits/PartCandPartDComplianceActions",
  FOR: "https://www.cms.gov/Medicare/Compliance-and-Audits/Part-C-and-Part-D-Compliance-and-Audits/PartCandPartDComplianceActions",
  NET: "https://www.cms.gov/Medicare/Compliance-and-Audits/Part-C-and-Part-D-Compliance-and-Audits",
  PRV: "https://www.hhs.gov/hipaa/for-professionals/compliance-enforcement/data/enforcement-highlights/index.html",
  PRC: "https://www.ftc.gov/reports/pharmacy-benefit-managers-report",
  CLM: "https://www.cms.gov/Medicare/Compliance-and-Audits/Part-C-and-Part-D-Compliance-and-Audits/PartCandPartDComplianceActions",
  RPT: "https://www.cms.gov/Medicare/Compliance-and-Audits/Part-C-and-Part-D-Compliance-and-Audits",
  AUD: "https://www.cms.gov/Medicare/Compliance-and-Audits/Part-C-and-Part-D-Compliance-and-Audits/ProgramAuditResults",
};

// Each template describes one possible finding for its category, in
// three plain, simple parts:
//   d      = Gap Analysis  — what is different or missing between the
//            contract and the regulation. Just the facts: contract says
//            this, regulation requires that.
//   impact = Impact Analysis — what could actually happen as a result of
//            that gap if it's left alone. The consequence, not the fix.
//   fix    = Recommended Fix — stand-in for an LLM-generated remediation
//            recommendation: the specific contract-language change or
//            operational step that would make this clause compliant.
//            Shown in the Compliance Report in place of the impact text.
//   a      = { status, detail } — what's actually been done about it so
//            far (status of remediation)
export const TEMPLATES = {
  REB: [
    {
      d: "The contract only reports rebates in one lump sum across all of the PBM's clients. The regulation requires rebates to be reported separately for each plan sponsor.",
      impact: "The plan sponsor can't verify it received the rebate amount it's actually owed. This can lead to a CMS audit finding and a clawback of underpaid rebates.",
      fix: "Amend the rebate reporting clause to require a per-plan-sponsor rebate statement, broken out and reconciled at every settlement date, delivered within 30 days of quarter close. Add a right for the plan sponsor to request a supporting rebate calculation worksheet on demand.",
      a: { status: "Escalated", detail: "Sent to legal for contract amendment; response due in 15 business days." },
    },
    {
      d: "The contract pools rebate money from all of the PBM's clients before splitting it up. The regulation requires each plan sponsor's rebate to be tracked and reconciled on its own.",
      impact: "A shortfall for one client could go unnoticed for months, since nothing checks each client's rebate amount individually.",
      fix: "Replace the pooled-rebate structure with a clause requiring per-client sub-ledgers tracked at the point of manufacturer collection. Require a quarterly reconciliation report per plan sponsor, with a named finance owner who attests to its accuracy in writing.",
      a: { status: "In Progress", detail: "Finance is rebuilding rebate ledgers at the per-plan level." },
    },
  ],
  FOR: [
    {
      d: "The contract lets manufacturer rebate size influence which drugs get preferred formulary placement. The regulation requires placement to be based on clinical value and net cost, not rebate size.",
      impact: "Members could be steered toward pricier brand drugs over equally effective generics, raising plan costs and inviting regulatory scrutiny for anti-steering violations.",
      fix: "Add language explicitly prohibiting rebate amount from being a scored factor in P&T Committee placement decisions. Require the committee to base tier decisions solely on clinical evidence and net cost, and add an annual third-party audit right over placement rationale.",
      a: { status: "Not Started", detail: "Flagged to P&T committee; no review scheduled yet." },
    },
    {
      d: "The contract doesn't require the P&T Committee to write down why it made a formulary decision. The regulation requires that reasoning to be documented.",
      impact: "If a member appeals a formulary decision, or a regulator asks for it, there's no paper trail to justify why the decision was made.",
      fix: "Require written rationale for every formulary decision, retained for at least 3 years and produced to the plan sponsor or regulators on request. Adopt a standardized minutes template capturing the clinical evidence reviewed, the cost comparison, and the vote outcome.",
      a: { status: "Resolved", detail: "Minutes template updated and adopted starting last committee cycle." },
    },
  ],
  NET: [
    {
      d: "The contract sets no minimum number of pharmacies required in rural areas. The regulation requires reasonable pharmacy access in every region, including rural ones.",
      impact: "Members in rural areas may struggle to fill maintenance prescriptions nearby, which can trigger access complaints and a network adequacy finding.",
      fix: "Add a network adequacy standard guaranteeing at least one in-network pharmacy within a defined drive-time (e.g., 30 minutes) for every rural ZIP code served. Require quarterly network gap reports and a 60-day cure period to contract a new pharmacy or activate mail-order for affected members.",
      a: { status: "In Progress", detail: "Network team sourcing two additional rural pharmacy partners." },
    },
  ],
  PRV: [
    {
      d: "The contract allows claims data to be shared with the PBM's affiliated analytics company without first checking whether that's the minimum data actually needed. The regulation requires that check before any health data is shared.",
      impact: "Sharing more health data than necessary raises the chance of a reportable privacy violation and possible breach-notification obligations.",
      fix: "Insert a minimum-necessary clause requiring documented business justification and privacy-officer sign-off before any claims data is shared with an affiliate. Limit shared fields to what's operationally required and require a signed data-sharing agreement covering purpose, retention, and deletion.",
      a: { status: "Escalated", detail: "Referred to privacy officer; data sharing paused pending review." },
    },
    {
      d: "The contract keeps member health data longer than the regulation allows, with no approved exception on file for the extra time.",
      impact: "The longer that data is kept, the bigger the exposure if there's ever a breach — and keeping it too long is itself a violation, breach or not.",
      fix: "Add a data retention schedule capping storage of member health data at the regulatory limit, with an automated purge workflow. Require documented, time-limited written approval for any retention beyond that limit, reviewed at least annually.",
      a: { status: "Not Started", detail: "No remediation owner assigned yet." },
    },
  ],
  PRC: [
    {
      d: "The contract doesn't require the PBM to show the plan sponsor the difference between what it bills the sponsor and what it pays the pharmacy. The regulation requires that markup to be disclosed regularly.",
      impact: "The plan sponsor could be significantly overpaying without knowing it, which can lead to breach-of-contract disputes once the markup is discovered.",
      fix: "Add a spread-pricing transparency clause requiring disclosure of the billed-vs-reimbursed difference on a per-claim or monthly aggregate basis. Require a standardized pricing report each billing cycle and grant the sponsor audit rights to verify the figures.",
      a: { status: "In Progress", detail: "Reporting template change scheduled for next quarter's release." },
    },
  ],
  CLM: [
    {
      d: "Some sampled claims charged members based on the drug's list price instead of the lower price the contract actually negotiated. The regulation requires the negotiated price to be used at checkout.",
      impact: "Members are being overcharged at the pharmacy counter, which creates a refund obligation and possible fines if the pattern holds plan-wide.",
      fix: "Add a system-level control requiring adjudication to apply the lower of the negotiated contract price or list price at point of sale. Include a corrective clause requiring retroactive reprocessing and member refunds for any misadjudicated claims within 90 days of discovery.",
      a: { status: "Resolved", detail: "Affected claims reprocessed; member refunds issued." },
    },
  ],
  RPT: [
    {
      d: "The contract's yearly transparency report doesn't break down generic drug usage by pharmacy channel. The regulation requires that breakdown in every reporting cycle.",
      impact: "Without that detail, the plan sponsor and regulators can't fully see how well generics are being used — which can itself be flagged as a reporting deficiency.",
      fix: "Amend the annual transparency report requirement to include a mandatory generic dispensing rate breakdown by pharmacy channel (retail, mail order, specialty). Build this into the standard reporting template and backfill at least one prior reporting cycle where data allows.",
      a: { status: "Not Started", detail: "Awaiting data warehouse access to build the new metric." },
    },
    {
      d: "The contract allows reports to go out 45 days later than the deadline the regulation requires.",
      impact: "The late reporting is a violation on its own, and it delays the sponsor's ability to catch cost problems early.",
      fix: "Shorten the contractual reporting deadline to match the regulatory requirement and add a per-day late-delivery fee to create a financial incentive for on-time reporting. Automate report generation so delivery isn't dependent on manual assembly.",
      a: { status: "In Progress", detail: "Automation pipeline in build; target go-live next cycle." },
    },
  ],
  AUD: [
    {
      d: "The contract only lets the plan sponsor audit the last 12 months of records. The regulation requires records to be kept — and available for audit — for 3 years.",
      impact: "The sponsor can't go back far enough to catch older billing errors or recover older overpayments, weakening its audit rights in practice.",
      fix: "Extend the audit-rights and record-retention clause to a full 3-year lookback period. Require records to be produced within a defined turnaround (e.g., 15 business days of a written request) and add the right to conduct at least one unannounced audit per year.",
      a: { status: "Escalated", detail: "Sent to legal for contract amendment ahead of next renewal." },
    },
  ],
};

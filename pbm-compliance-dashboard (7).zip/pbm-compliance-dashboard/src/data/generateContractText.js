// Builds a synthetic "full contract text" for the document viewer.
//
// There's no real PDF/DOCX text extraction in this project yet, so this
// generates a plausible, structured contract (numbered articles) and
// slots each violation's finding into the article that matches its
// category — the paragraphs that correspond to an actual finding are
// flagged `broken: true` so the viewer can highlight them.
//
// Swap this out once real text extraction exists: instead of generating
// paragraphs, you'd load the real extracted text and use offsets the
// LLM returns (start/end index or quoted span) to mark the same spots.

const ARTICLE_MAP = {
  REB: { num: 4, heading: "Rebates & Financial Terms" },
  FOR: { num: 5, heading: "Formulary Management" },
  NET: { num: 6, heading: "Network Adequacy & Pharmacy Access" },
  PRV: { num: 7, heading: "Data Privacy & Security" },
  PRC: { num: 8, heading: "Pricing & Spread Transparency" },
  CLM: { num: 9, heading: "Claims Adjudication" },
  RPT: { num: 10, heading: "Reporting & Disclosure Obligations" },
  AUD: { num: 11, heading: "Audit & Inspection Rights" },
};

const NEUTRAL_TEXT = {
  REB: "The Company shall calculate and remit rebate amounts owed to the Client in accordance with the methodology set out in Exhibit C, subject to reconciliation at each settlement date.",
  FOR: "Formulary placement decisions shall be made by the Pharmacy & Therapeutics Committee in accordance with the clinical review process described in Exhibit D.",
  NET: "The Company shall maintain a retail pharmacy network sufficient to provide Covered Persons with reasonable geographic access to Covered Services.",
  PRV: "The Company shall safeguard Protected Health Information in accordance with the Privacy and Security Rules and the data handling requirements set out in Exhibit F.",
  PRC: "Pricing terms, including any applicable discounts, dispensing fees, and administrative charges, are set out in Exhibit B and shall be disclosed to the Client upon request.",
  CLM: "Claims shall be adjudicated in accordance with the pricing and benefit design rules configured by the Client and documented in Exhibit A.",
  RPT: "The Company shall provide the Client with periodic utilization and financial reports on the schedule and in the format described in Exhibit E.",
  AUD: "The Client, or its designated representative, shall have the right to audit the Company's records relevant to this Agreement upon reasonable prior written notice.",
};

const FILLER_ARTICLES_BEFORE = [
  {
    num: 1,
    heading: "Definitions",
    text: "Capitalized terms used in this Agreement shall have the meanings set forth in Exhibit A unless otherwise defined herein.",
  },
  {
    num: 2,
    heading: "Term & Termination",
    text: "This Agreement shall commence on the Effective Date and continue for an initial term of three (3) years, renewing automatically for successive one-year terms unless either party provides written notice of non-renewal at least ninety (90) days prior to the end of the then-current term.",
  },
  {
    num: 3,
    heading: "Scope of Services",
    text: "The Company shall provide pharmacy benefit management services to the Client's plan members as described in this Agreement and its accompanying Exhibits.",
  },
];

const FILLER_ARTICLES_AFTER = [
  {
    num: 12,
    heading: "General Provisions",
    text: "This Agreement, together with its Exhibits, constitutes the entire agreement between the parties and supersedes all prior negotiations, representations, or agreements relating to its subject matter.",
  },
];

export function generateContractDocument(contractLabel, violationsForContract = []) {
  const byArticleCode = {};
  violationsForContract.forEach((v) => {
    if (!byArticleCode[v.categoryCode]) byArticleCode[v.categoryCode] = [];
    byArticleCode[v.categoryCode].push(v);
  });

  const sections = [];

  FILLER_ARTICLES_BEFORE.forEach((a) => {
    sections.push({ num: a.num, heading: a.heading, paragraphs: [{ text: a.text, broken: false }] });
  });

  Object.entries(ARTICLE_MAP).forEach(([code, meta]) => {
    const issues = byArticleCode[code] || [];
    const paragraphs = [{ text: NEUTRAL_TEXT[code], broken: false }];

    issues.forEach((v) => {
      paragraphs.push({
        text: `${v.clause} ${v.description}`,
        broken: true,
        meta: {
          id: v.id,
          risk: v.risk,
          regulation: v.regulation,
          actionTaken: v.actionTaken,
          impactAnalysis: v.impactAnalysis,
          impactLink: v.impactLink,
          remediation: v.remediation,
        },
      });
    });

    sections.push({ num: meta.num, heading: meta.heading, paragraphs });
  });

  FILLER_ARTICLES_AFTER.forEach((a) => {
    sections.push({ num: a.num, heading: a.heading, paragraphs: [{ text: a.text, broken: false }] });
  });

  sections.sort((a, b) => a.num - b.num);

  return { title: contractLabel, sections };
}

// Combines every (contract, regulation) result in the matrix into one
// summary — this is what the top-of-page KPI cards and charts on the
// Overview page should show when multiple documents are selected,
// as opposed to PairDetail which shows just one selected cell.
export function aggregateMatrix(contracts, regulations, matrix) {
  const pairs = [];
  contracts.forEach((c) => {
    regulations.forEach((r) => {
      const result = matrix[c.id]?.[r.id];
      if (result) pairs.push({ contract: c, regulation: r, result });
    });
  });

  // Each unique contract's clause count is counted once — not once per
  // regulation it was checked against — since the clause count is a
  // property of the contract, not of the pairing.
  const clausesByContract = {};
  pairs.forEach(({ contract, result }) => {
    clausesByContract[contract.id] = result.totalClauses;
  });
  const totalClauses = Object.values(clausesByContract).reduce((sum, n) => sum + n, 0);

  const riskCounts = { High: 0, Moderate: 0, Low: 0 };
  const categoryTotals = {};
  let totalViolations = 0;

  pairs.forEach(({ result }) => {
    totalViolations += result.violations.length;
    riskCounts.High += result.riskCounts.High;
    riskCounts.Moderate += result.riskCounts.Moderate;
    riskCounts.Low += result.riskCounts.Low;
    result.categoryBreakdown.forEach((c) => {
      if (!categoryTotals[c.fullName]) {
        categoryTotals[c.fullName] = { name: c.name, fullName: c.fullName, count: 0 };
      }
      categoryTotals[c.fullName].count += c.count;
    });
  });

  const categoryBreakdown = Object.values(categoryTotals).sort((a, b) => b.count - a.count);

  const avgScore = pairs.length
    ? Math.round(pairs.reduce((sum, p) => sum + p.result.complianceScore, 0) / pairs.length)
    : 0;

  // Average the trend across every pair, cycle by cycle — every pair's
  // trend shares the same cycle labels ("Audit 1" ... "Current").
  let trend = [];
  if (pairs.length) {
    const cycleCount = pairs[0].result.trend.length;
    trend = Array.from({ length: cycleCount }, (_, i) => {
      const label = pairs[0].result.trend[i].cycle;
      const avg = Math.round(
        pairs.reduce((sum, p) => sum + (p.result.trend[i]?.score ?? 0), 0) / pairs.length
      );
      return { cycle: label, score: avg };
    });
  }

  let worst = null;
  pairs.forEach((p) => {
    if (!worst || p.result.complianceScore < worst.result.complianceScore) worst = p;
  });

  return { pairCount: pairs.length, totalClauses, totalViolations, riskCounts, categoryBreakdown, avgScore, trend, worst };
}

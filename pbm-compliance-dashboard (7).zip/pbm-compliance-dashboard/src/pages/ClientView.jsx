import { useMemo, useState } from "react";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableCell from "@mui/material/TableCell";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Tooltip from "@mui/material/Tooltip";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";
import ToggleButton from "@mui/material/ToggleButton";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import DescriptionRoundedIcon from "@mui/icons-material/DescriptionRounded";
import AuditFindingsBadge from "../components/AuditFindingsBadge";
import NotifyButton from "../components/NotifyButton";
import { CLIENT_ROWS } from "../data/clientRows";

const RISK_DOT = { High: "#B3432F", Moderate: "#B8842E", Low: "#3C7A5C" };
const RISK_LEVELS = ["All", "High", "Moderate", "Low"];

// Client-facing counterpart to Vendor View. This is still on dummy,
// static data (CLIENT_ROWS) rather than the live contract/regulation
// matrix — same column shape as Vendor View so it's a drop-in once a
// real client dataset/API exists.
export default function ClientView() {
  const allRows = CLIENT_ROWS;

  const [riskFilter, setRiskFilter] = useState("All");
  const [segmentFilter, setSegmentFilter] = useState("All");
  const [query, setQuery] = useState("");
  const [notifiedIds, setNotifiedIds] = useState(() => new Set());

  function toggleNotified(id) {
    setNotifiedIds((prev) => {
      const next = new Set(prev);
      next.add(id);
      return next;
    });
  }

  const segments = useMemo(
    () => Array.from(new Set(allRows.map((r) => r.segment))).sort(),
    [allRows]
  );

  const rows = useMemo(() => {
    return allRows.filter((row) => {
      const matchesRisk = riskFilter === "All" || row.risk === riskFilter;
      const matchesSegment = segmentFilter === "All" || row.segment === segmentFilter;
      const q = query.trim().toLowerCase();
      const matchesQuery =
        !q ||
        row.clientName.toLowerCase().includes(q) ||
        row.planLabel.toLowerCase().includes(q) ||
        row.segment.toLowerCase().includes(q);
      return matchesRisk && matchesSegment && matchesQuery;
    });
  }, [allRows, riskFilter, segmentFilter, query]);

  return (
    <Box>
      <Typography sx={{ fontSize: 11.5, color: "#8992A1", mb: 1.5 }}>
        Sample client roster — not yet wired to the contract/regulation review engine.
      </Typography>

      <Box sx={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 1.5, mb: 1.25 }}>
        <ToggleButtonGroup exclusive size="small" value={riskFilter} onChange={(e, val) => val && setRiskFilter(val)}>
          {RISK_LEVELS.map((lvl) => (
            <ToggleButton key={lvl} value={lvl} sx={{ textTransform: "none", fontSize: 12.5, px: 1.75 }}>
              {lvl}
            </ToggleButton>
          ))}
        </ToggleButtonGroup>

        <TextField
          size="small"
          placeholder="Search client, plan, or segment"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          sx={{ minWidth: 280, bgcolor: "background.paper" }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchRoundedIcon sx={{ fontSize: 18, color: "#8992A1" }} />
              </InputAdornment>
            ),
          }}
        />
      </Box>

      <Box sx={{ display: "flex", gap: 1.5, mb: 1.75, flexWrap: "wrap" }}>
        <FormControl size="small" sx={{ minWidth: 220 }}>
          <Select
            value={segmentFilter}
            onChange={(e) => setSegmentFilter(e.target.value)}
            sx={{ fontSize: 12.5, bgcolor: "background.paper" }}
          >
            <MenuItem value="All" sx={{ fontSize: 12.5 }}>
              All segments
            </MenuItem>
            {segments.map((s) => (
              <MenuItem key={s} value={s} sx={{ fontSize: 12.5 }}>
                {s}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Box>

      <TableContainer component={Paper} variant="outlined">
        <Table size="small">
          <TableHead>
            <TableRow sx={{ "& th": { bgcolor: "#FAFBFC", fontSize: 11, color: "text.secondary", fontWeight: 500 } }}>
              <TableCell>Client Name</TableCell>
              <TableCell>Plan</TableCell>
              <TableCell>Segment</TableCell>
              <TableCell>Report</TableCell>
              <TableCell>Compliance Score</TableCell>
              <TableCell>Audit Findings</TableCell>
              <TableCell>Notify</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} align="center" sx={{ py: 5, color: "#8992A1" }}>
                  No clients match the current filter.
                </TableCell>
              </TableRow>
            ) : (
              rows.map((row) => (
                <TableRow key={row.id} hover>
                  <TableCell sx={{ fontWeight: 500, fontSize: 12.5 }}>{row.clientName}</TableCell>
                  <TableCell sx={{ fontSize: 12.5, color: "text.secondary", maxWidth: 260 }}>
                    {row.planLabel}
                  </TableCell>
                  <TableCell sx={{ fontSize: 12.5 }}>{row.segment}</TableCell>
                  <TableCell>
                    <Tooltip title={row.reviewed ? "Sample data — not wired to the review engine yet" : "No review on file for this client"}>
                      <span>
                        <Button
                          size="small"
                          variant="outlined"
                          disabled={!row.reviewed}
                          startIcon={
                            <DescriptionRoundedIcon
                              sx={{ fontSize: 15, color: row.reviewed ? RISK_DOT[row.risk] : undefined }}
                            />
                          }
                          sx={{ fontSize: 12, py: 0.4 }}
                        >
                          View Report
                        </Button>
                      </span>
                    </Tooltip>
                  </TableCell>
                  <TableCell sx={{ fontSize: 12.5, fontWeight: 600 }}>
                    {row.complianceScore != null ? `${row.complianceScore}%` : "—"}
                  </TableCell>
                  <TableCell>
                    <AuditFindingsBadge findings={row.reviewed ? row.findings : null} />
                  </TableCell>
                  <TableCell>
                    <NotifyButton
                      notified={notifiedIds.has(row.id)}
                      onToggle={() => toggleNotified(row.id)}
                    />
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {rows.length > 0 && (
        <Typography sx={{ fontSize: 11.5, color: "#8992A1", mt: 1.25 }}>
          Showing {rows.length} of {allRows.length} clients
        </Typography>
      )}
    </Box>
  );
}

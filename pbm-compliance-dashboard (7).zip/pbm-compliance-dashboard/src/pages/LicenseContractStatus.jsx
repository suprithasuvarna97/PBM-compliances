import { useMemo, useState } from "react";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableCell from "@mui/material/TableCell";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import Typography from "@mui/material/Typography";
import Chip from "@mui/material/Chip";
import Tooltip from "@mui/material/Tooltip";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import DescriptionRoundedIcon from "@mui/icons-material/DescriptionRounded";
import { LICENSE_ROWS } from "../data/licenseRows";

const STATUS_COLORS = {
  Active: { bg: "#DEEAE2", fg: "#2C5A41" },
  "Renewal Due Soon": { bg: "#F5EAD7", fg: "#7A5417" },
  Expired: { bg: "#F6E4DF", fg: "#8A2E1F" },
};

const ENTITY_TYPES = ["All", "Vendor", "Client"];

function StatusChip({ status }) {
  const c = STATUS_COLORS[status] || { bg: "#EEF0F3", fg: "#5B6472" };
  return <Chip size="small" label={status} sx={{ bgcolor: c.bg, color: c.fg, fontWeight: 600 }} />;
}

function daysRemainingColor(days) {
  if (days < 0) return "#8A2E1F";
  if (days <= 30) return "#7A5417";
  return "#2C5A41";
}

// New tab: tracks each vendor's / client's regulatory licenses and filing
// status, separately from contract clause compliance. Dummy data for now
// (LICENSE_ROWS) — filterable by entity type (Vendor vs. Client), state,
// and status, the way the request asked for.
export default function LicenseContractStatus() {
  const allRows = LICENSE_ROWS;

  const [entityTypeFilter, setEntityTypeFilter] = useState("All");
  const [entityFilter, setEntityFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [query, setQuery] = useState("");

  const entityOptions = useMemo(() => {
    const pool = entityTypeFilter === "All" ? allRows : allRows.filter((r) => r.entityType === entityTypeFilter);
    return Array.from(new Set(pool.map((r) => r.entity))).sort();
  }, [allRows, entityTypeFilter]);

  const statusOptions = useMemo(() => Array.from(new Set(allRows.map((r) => r.status))).sort(), [allRows]);

  const rows = useMemo(() => {
    return allRows.filter((row) => {
      const matchesType = entityTypeFilter === "All" || row.entityType === entityTypeFilter;
      const matchesEntity = entityFilter === "All" || row.entity === entityFilter;
      const matchesStatus = statusFilter === "All" || row.status === statusFilter;
      const q = query.trim().toLowerCase();
      const matchesQuery =
        !q ||
        row.entity.toLowerCase().includes(q) ||
        row.licenseType.toLowerCase().includes(q) ||
        row.licenseNumber.toLowerCase().includes(q) ||
        row.state.toLowerCase().includes(q);
      return matchesType && matchesEntity && matchesStatus && matchesQuery;
    });
  }, [allRows, entityTypeFilter, entityFilter, statusFilter, query]);

  return (
    <Box>
      <Typography sx={{ fontSize: 11.5, color: "#8992A1", mb: 1.5 }}>
        Sample licensing & filing data — filter by vendor or client below.
      </Typography>

      <Box sx={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 1.5, mb: 1.75 }}>
        <Box sx={{ display: "flex", gap: 1.5, flexWrap: "wrap" }}>
          <FormControl size="small" sx={{ minWidth: 160 }}>
            <InputLabel sx={{ fontSize: 12.5 }}>Vendor / Client</InputLabel>
            <Select
              label="Vendor / Client"
              value={entityTypeFilter}
              onChange={(e) => {
                setEntityTypeFilter(e.target.value);
                setEntityFilter("All");
              }}
              sx={{ fontSize: 12.5, bgcolor: "background.paper" }}
            >
              {ENTITY_TYPES.map((t) => (
                <MenuItem key={t} value={t} sx={{ fontSize: 12.5 }}>
                  {t === "All" ? "All entities" : `${t}s`}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <FormControl size="small" sx={{ minWidth: 240 }}>
            <InputLabel sx={{ fontSize: 12.5 }}>Entity</InputLabel>
            <Select
              label="Entity"
              value={entityFilter}
              onChange={(e) => setEntityFilter(e.target.value)}
              sx={{ fontSize: 12.5, bgcolor: "background.paper" }}
            >
              <MenuItem value="All" sx={{ fontSize: 12.5 }}>
                All {entityTypeFilter === "All" ? "vendors & clients" : `${entityTypeFilter.toLowerCase()}s`}
              </MenuItem>
              {entityOptions.map((e) => (
                <MenuItem key={e} value={e} sx={{ fontSize: 12.5 }}>
                  {e}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <FormControl size="small" sx={{ minWidth: 190 }}>
            <InputLabel sx={{ fontSize: 12.5 }}>Status</InputLabel>
            <Select
              label="Status"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              sx={{ fontSize: 12.5, bgcolor: "background.paper" }}
            >
              <MenuItem value="All" sx={{ fontSize: 12.5 }}>
                All statuses
              </MenuItem>
              {statusOptions.map((s) => (
                <MenuItem key={s} value={s} sx={{ fontSize: 12.5 }}>
                  {s}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Box>

        <TextField
          size="small"
          placeholder="Search entity, license type, or number"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          sx={{ minWidth: 280, bgcolor: "background.paper" }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchRoundedIcon sx={{ fontSize: 18, color: "#8992A1" }} />
              </InputAdornment>
            ),
          }}
        />
      </Box>

      <TableContainer component={Paper} variant="outlined">
        <Table size="small">
          <TableHead>
            <TableRow sx={{ "& th": { bgcolor: "#FAFBFC", fontSize: 11, color: "text.secondary", fontWeight: 500 } }}>
              <TableCell>Entity</TableCell>
              <TableCell>State</TableCell>
              <TableCell>License Type</TableCell>
              <TableCell>License Number</TableCell>
              <TableCell>Expiration Date</TableCell>
              <TableCell>Days Remaining</TableCell>
              <TableCell>Renewal Owner</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Documents</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.length === 0 ? (
              <TableRow>
                <TableCell colSpan={9} align="center" sx={{ py: 5, color: "#8992A1" }}>
                  No licenses match the current filter.
                </TableCell>
              </TableRow>
            ) : (
              rows.map((row) => (
                <TableRow key={row.id} hover>
                  <TableCell sx={{ fontWeight: 500, fontSize: 12.5 }}>
                    {row.entity}
                    <Typography sx={{ fontSize: 10.5, color: "#8992A1" }}>{row.entityType}</Typography>
                  </TableCell>
                  <TableCell sx={{ fontSize: 12.5 }}>{row.state}</TableCell>
                  <TableCell sx={{ fontSize: 12.5, color: "text.secondary" }}>{row.licenseType}</TableCell>
                  <TableCell sx={{ fontSize: 12.5, whiteSpace: "nowrap" }}>{row.licenseNumber}</TableCell>
                  <TableCell sx={{ fontSize: 12.5, whiteSpace: "nowrap" }}>{row.expirationDate}</TableCell>
                  <TableCell sx={{ fontSize: 12.5, fontWeight: 600, color: daysRemainingColor(row.daysRemaining) }}>
                    {row.daysRemaining < 0 ? `${Math.abs(row.daysRemaining)} overdue` : row.daysRemaining}
                  </TableCell>
                  <TableCell sx={{ fontSize: 12.5 }}>{row.renewalOwner}</TableCell>
                  <TableCell>
                    <StatusChip status={row.status} />
                  </TableCell>
                  <TableCell>
                    <Box sx={{ display: "flex", gap: 0.5, flexWrap: "wrap", maxWidth: 200 }}>
                      {row.documents.map((docName) => (
                        <Tooltip key={docName} title={docName}>
                          <Chip
                            size="small"
                            icon={<DescriptionRoundedIcon sx={{ fontSize: 13 }} />}
                            label={docName}
                            variant="outlined"
                            sx={{ fontSize: 10.5, maxWidth: 130 }}
                          />
                        </Tooltip>
                      ))}
                    </Box>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {rows.length > 0 && (
        <Typography sx={{ fontSize: 11.5, color: "#8992A1", mt: 1.25 }}>
          Showing {rows.length} of {allRows.length} licenses
        </Typography>
      )}
    </Box>
  );
}

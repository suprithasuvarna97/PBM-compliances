import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
import GridViewRoundedIcon from "@mui/icons-material/GridViewRounded";
import ReportProblemRoundedIcon from "@mui/icons-material/ReportProblemRounded";
import ChecklistRtlRoundedIcon from "@mui/icons-material/ChecklistRtlRounded";
import KpiCard from "../components/KpiCard";
import ComplianceHeatmap from "../components/ComplianceHeatmap";
import RiskDonutChart from "../components/charts/RiskDonutChart";
import CategoryBarChart from "../components/charts/CategoryBarChart";
import TrendLineChart from "../components/charts/TrendLineChart";
import { aggregateMatrix } from "../data/aggregateMatrix";

// One set of KPI cards and charts, driven by the single active contract
// checked against every currently selected regulation ("Option A": one
// contract, multiple regulations, checked together). The heatmap below
// is a per-regulation breakdown of that same data; it doesn't change
// what the cards/charts show.
export default function Overview({ contracts, regulations, matrix }) {
  const summary = aggregateMatrix(contracts, regulations, matrix);
  const contractLabel = contracts[0]?.label;

  return (
    <Box>
      <Grid container spacing={1.75} sx={{ mb: 2 }}>
        <Grid item xs={12} sm={6} md={3}>
          <KpiCard
            icon={<GridViewRoundedIcon sx={{ fontSize: 18 }} />}
            label="Regulations Checked"
            value={regulations.length}
            sub={contractLabel ? `against ${contractLabel.split("—")[0].trim()}` : "no contract selected"}
            tone="#2F5D8C"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <KpiCard
            icon={<ChecklistRtlRoundedIcon sx={{ fontSize: 18 }} />}
            label="Clauses Evaluated"
            value={summary.totalClauses}
            sub="in this contract"
            tone="#2F5D8C"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <KpiCard
            icon={<ReportProblemRoundedIcon sx={{ fontSize: 18 }} />}
            label="Total Rules Broken"
            value={summary.totalViolations}
            sub="across all checked regulations"
            tone="#B8842E"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <KpiCard
            icon={<ReportProblemRoundedIcon sx={{ fontSize: 18 }} />}
            label="Total High Risk Findings"
            value={summary.riskCounts.High}
            sub="across all checked regulations"
            tone="#B3432F"
          />
        </Grid>
      </Grid>

      <Grid container spacing={1.75} sx={{ mb: 1.75 }}>
        <Grid item xs={12} md={5}>
          <Paper variant="outlined" sx={{ p: "16px 18px 8px", height: "100%" }}>
            <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", mb: 0.75 }}>
              <Typography variant="h6" sx={{ fontSize: 15 }}>
                Risk Distribution
              </Typography>
              <Typography sx={{ fontSize: 11.5, color: "#8992A1" }}>all checked regulations</Typography>
            </Box>
            <RiskDonutChart riskCounts={summary.riskCounts} />
          </Paper>
        </Grid>
        <Grid item xs={12} md={7}>
          <Paper variant="outlined" sx={{ p: "16px 18px 8px", height: "100%" }}>
            <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", mb: 0.75 }}>
              <Typography variant="h6" sx={{ fontSize: 15 }}>
                Violations by Category
              </Typography>
              <Typography sx={{ fontSize: 11.5, color: "#8992A1" }}>all checked regulations</Typography>
            </Box>
            <CategoryBarChart data={summary.categoryBreakdown} />
          </Paper>
        </Grid>
      </Grid>

      <Paper variant="outlined" sx={{ p: "16px 18px 8px", mb: 1.75 }}>
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", mb: 0.75 }}>
          <Typography variant="h6" sx={{ fontSize: 15 }}>
            Compliance Score Trend
          </Typography>
          <Typography sx={{ fontSize: 11.5, color: "#8992A1" }}>
            average across checked regulations · last 6 review cycles
          </Typography>
        </Box>
        <TrendLineChart data={summary.trend} />
      </Paper>

      <Paper variant="outlined" sx={{ p: "16px 18px" }}>
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", mb: 1.5 }}>
          <Typography variant="h6" sx={{ fontSize: 15 }}>
            Score by Regulation
          </Typography>
          {summary.worst && (
            <Typography sx={{ fontSize: 11.5, color: "#8992A1" }}>
              Lowest score: {summary.worst.regulation.label.split("(")[0].trim()} ({summary.worst.result.complianceScore}%)
            </Typography>
          )}
        </Box>
        <ComplianceHeatmap contracts={contracts} regulations={regulations} matrix={matrix} />
      </Paper>
    </Box>
  );
}

import { useState } from "react";
import Box from "@mui/material/Box";
import CircularProgress from "@mui/material/CircularProgress";
import Typography from "@mui/material/Typography";
import Sidebar from "./components/Sidebar";
import TopBar from "./components/TopBar";
import Overview from "./pages/Overview";
import ViolationLog from "./pages/ViolationLog";
import VendorView from "./pages/VendorView";
import ClientView from "./pages/ClientView";
import LicenseContractStatus from "./pages/LicenseContractStatus";
import UploadsDialog from "./components/UploadsDialog";
import DocumentViewerDialog from "./components/DocumentViewerDialog";
import RawDocumentViewerDialog from "./components/RawDocumentViewerDialog";
import ReportViewerDialog from "./components/ReportViewerDialog";
import { CONTRACT_DOCS, REFERENCE_DOCS } from "./data/catalog";
import { useMatrixAnalysis } from "./hooks/useMatrixAnalysis";

const initialContractPool = CONTRACT_DOCS.map((label, i) => ({ id: `c-catalog-${i}`, label, isUpload: false }));
const initialRegulationPool = REFERENCE_DOCS.map((label, i) => ({ id: `r-catalog-${i}`, label, isUpload: false }));

const TAB_TITLES = {
  overview: "Compliance Overview",
  table: "Violation Log",
  vendors: "Vendor View",
  clients: "Client View",
  licenses: "License & Contract Status",
};

// These tabs run on their own dummy/static data rather than the
// contract+regulation review matrix, so they should render regardless of
// what's selected in the top bar (same treatment Vendor View already got).
const TABS_WITHOUT_SELECTION_GATE = ["vendors", "clients", "licenses"];

export default function App() {
  const [activeTab, setActiveTab] = useState("overview");

  const [contractPool, setContractPool] = useState(initialContractPool);
  const [regulationPool, setRegulationPool] = useState(initialRegulationPool);

  // Option A: ONE active contract, checked against MULTIPLE regulations
  // together. The contract picker is single-select; regulations stay
  // multi-select.
  const [selectedContractId, setSelectedContractId] = useState(initialContractPool[0].id);
  const [selectedRegulationIds, setSelectedRegulationIds] = useState([initialRegulationPool[0].id]);

  const [runNonce, setRunNonce] = useState(0);
  const [hasRunReview, setHasRunReview] = useState(false);
  const [uploadsOpen, setUploadsOpen] = useState(false);
  const [viewerContract, setViewerContract] = useState(null); // { id, label } | null
  const [rawViewerContract, setRawViewerContract] = useState(null); // { id, label } | null
  const [reportViewerContract, setReportViewerContract] = useState(null); // full vendor row from buildVendorRows, or null

  const selectedRegulations = regulationPool.filter((r) => selectedRegulationIds.includes(r.id));
  const activeContract = contractPool.find((c) => c.id === selectedContractId) || null;

  // Single source of truth for every page: the review runs for EVERY
  // contract in the pool (not just the active one) against every selected
  // regulation. Overview / Violation Log filter this down to the active
  // contract; Vendor View shows every contract's row; the document viewer
  // reads any contract's findings straight out of the same matrix. This is
  // what keeps every tab showing identical numbers for the same contract.
  const { isAnalyzing, matrix } = useMatrixAnalysis({
    contracts: contractPool,
    regulations: selectedRegulations,
    runNonce,
  });

  function handleUploadContract(fileName) {
    const id = `c-upload-${Date.now()}`;
    setContractPool((pool) => [...pool, { id, label: fileName, isUpload: true }]);
    setSelectedContractId(id);
  }

  function handleUploadRegulation(fileName) {
    const id = `r-upload-${Date.now()}`;
    setRegulationPool((pool) => [...pool, { id, label: fileName, isUpload: true }]);
    setSelectedRegulationIds((ids) => [...ids, id]);
  }

  // Findings for a given contract, aggregated across every regulation it
  // has been checked against so far — reads straight from the shared
  // matrix, so this works for ANY contract in the pool, not just the
  // currently active one.
  function violationsForContract(contractId) {
    const perRegulation = matrix[contractId];
    if (!perRegulation) return [];
    return Object.values(perRegulation).flatMap((result) => result.violations);
  }

  const activeContracts = activeContract ? [activeContract] : [];
  const noSelection = !activeContract || selectedRegulations.length === 0;

  return (
    <Box sx={{ display: "flex", minHeight: "100vh", bgcolor: "background.default" }}>
      <Sidebar activeTab={activeTab} onChangeTab={setActiveTab} />

      <Box sx={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
        <TopBar
          title={TAB_TITLES[activeTab]}
          subtitle="Select one contract and one or more regulations to check together"
          contractPool={contractPool}
          selectedContractId={selectedContractId}
          onChangeSelectedContract={setSelectedContractId}
          onUploadContract={handleUploadContract}
          regulationPool={regulationPool}
          selectedRegulationIds={selectedRegulationIds}
          onChangeSelectedRegulations={setSelectedRegulationIds}
          onUploadRegulation={handleUploadRegulation}
          isAnalyzing={isAnalyzing}
          onRun={() => {
            setRunNonce((n) => n + 1);
            setHasRunReview(true);
          }}
          onOpenUploads={() => setUploadsOpen(true)}
          onViewActiveContract={() => activeContract && setViewerContract(activeContract)}
          onViewRawDocument={() => activeContract && setRawViewerContract(activeContract)}
          hasRunReview={hasRunReview}
        />

        <Box sx={{ p: "24px 28px 40px", flex: 1 }}>
          {isAnalyzing || (!TABS_WITHOUT_SELECTION_GATE.includes(activeTab) && noSelection) ? (
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: 1.25,
                py: 10,
                color: "text.secondary",
              }}
            >
              {isAnalyzing ? (
                <>
                  <CircularProgress size={26} thickness={4} />
                  <Typography sx={{ fontSize: 13 }}>
                    Reviewing {contractPool.length} contract{contractPool.length !== 1 ? "s" : ""} against{" "}
                    {selectedRegulations.length} regulation{selectedRegulations.length !== 1 ? "s" : ""}…
                  </Typography>
                </>
              ) : (
                <Typography sx={{ fontSize: 13 }}>
                  Select a contract and at least one regulation to run a review.
                </Typography>
              )}
            </Box>
          ) : activeTab === "overview" ? (
            <Overview contracts={activeContracts} regulations={selectedRegulations} matrix={matrix} />
          ) : activeTab === "table" ? (
            <ViolationLog contracts={activeContracts} regulations={selectedRegulations} matrix={matrix} />
          ) : activeTab === "vendors" ? (
            <VendorView
              vendors={contractPool}
              regulations={selectedRegulations}
              matrix={matrix}
              onViewReport={(vendor) => setReportViewerContract(vendor)}
            />
          ) : activeTab === "clients" ? (
            <ClientView />
          ) : (
            <LicenseContractStatus />
          )}
        </Box>
      </Box>

      <UploadsDialog
        open={uploadsOpen}
        onClose={() => setUploadsOpen(false)}
        contractPool={contractPool}
        regulationPool={regulationPool}
        onViewContract={(contract) => {
          setViewerContract(contract);
          setUploadsOpen(false);
        }}
      />

      <DocumentViewerDialog
        open={Boolean(viewerContract)}
        onClose={() => setViewerContract(null)}
        contractLabel={viewerContract?.label || ""}
        violations={viewerContract ? violationsForContract(viewerContract.id) : []}
      />

      <RawDocumentViewerDialog
        open={Boolean(rawViewerContract)}
        onClose={() => setRawViewerContract(null)}
        contractLabel={rawViewerContract?.label || ""}
      />

      <ReportViewerDialog
        open={Boolean(reportViewerContract)}
        onClose={() => setReportViewerContract(null)}
        contractLabel={reportViewerContract?.contractLabel || ""}
        vendorName={reportViewerContract?.vendorName}
        department={reportViewerContract?.department}
        complianceScore={reportViewerContract?.complianceScore}
        findings={reportViewerContract?.findings}
        regulations={selectedRegulations}
        violations={reportViewerContract ? violationsForContract(reportViewerContract.id) : []}
      />
    </Box>
  );
}

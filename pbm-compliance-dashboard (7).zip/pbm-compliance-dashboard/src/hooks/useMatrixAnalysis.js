import { useEffect, useState } from "react";
import { generateAnalysis } from "../data/generateAnalysis";

// Runs the (simulated) review for every contract × every regulation passed
// in, on "Run Review" (runNonce bump). Returns a matrix keyed by contract
// id, then regulation id:
//
//   matrix[contractId][regulationId] = { violations, riskCounts, ... }
//
// This is the single source of truth for compliance data in the app —
// Overview, Violation Log, and Vendor View all read from the same matrix
// (just filtered to different contracts), so a given contract+regulation
// pair always shows identical numbers no matter which page you're on.
// The seed is derived purely from the pair's own labels + runNonce (not
// from array position), so results stay consistent regardless of which
// page's array ordering happened to compute them first.
//
// contracts/regulations are read at call time via closure (same pattern
// used throughout this app) so the effect only re-runs when the user
// explicitly presses Run Review, not on every selection change.
export function useMatrixAnalysis({ contracts, regulations, runNonce }) {
  const [isAnalyzing, setIsAnalyzing] = useState(true);
  const [matrix, setMatrix] = useState({});

  useEffect(() => {
    let cancelled = false;
    setIsAnalyzing(true);

    const pairCount = Math.max(1, contracts.length * regulations.length);
    const latency = 900 + Math.min(1800, pairCount * 180);

    const timer = setTimeout(() => {
      if (cancelled) return;
      const next = {};
      contracts.forEach((c) => {
        next[c.id] = {};
        regulations.forEach((r) => {
          next[c.id][r.id] = generateAnalysis(c.label, r.label, runNonce);
        });
      });
      setMatrix(next);
      setIsAnalyzing(false);
    }, latency);

    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runNonce]);

  return { isAnalyzing, matrix };
}

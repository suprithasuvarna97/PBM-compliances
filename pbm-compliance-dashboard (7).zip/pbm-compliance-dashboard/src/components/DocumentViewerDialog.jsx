import { useMemo } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import IconButton from "@mui/material/IconButton";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import { generateContractDocument } from "../data/generateContractText";

// "View output document" — the OUTCOME of running the raw document
// through review. Shows the full contract text with ONLY the broken
// clauses highlighted green — nothing else layered on top (no risk badge,
// no regulation name, no action-taken status). For the fuller audit-style
// report with all of that context, see ReportViewerDialog.jsx, used by
// Vendor View's "View Report".
//
// This renders SYNTHETIC contract text (see generateContractText.js) since
// there's no real PDF/DOCX extraction wired up yet — swap the document
// source there once one exists; this component doesn't need to change.
export default function DocumentViewerDialog({ open, onClose, contractLabel, violations = [] }) {
  const doc = useMemo(() => generateContractDocument(contractLabel, violations), [contractLabel, violations]);

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth scroll="paper">
      <DialogTitle sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", pr: 1.5 }}>
        <Box>
          <Typography sx={{ fontFamily: "'Source Serif 4', serif", fontSize: 17, fontWeight: 600 }}>
            {contractLabel}
          </Typography>
          <Typography sx={{ fontSize: 11.5, color: "text.secondary", fontWeight: 400 }}>
            Output document — highlighted text is exactly what broke a rule, nothing else
          </Typography>
        </Box>
        <IconButton onClick={onClose} size="small">
          <CloseRoundedIcon fontSize="small" />
        </IconButton>
      </DialogTitle>

      <DialogContent dividers sx={{ fontFamily: "'IBM Plex Sans', sans-serif" }}>
        {violations.length === 0 && (
          <Box
            sx={{
              mb: 2.5,
              p: 1.5,
              borderRadius: "6px",
              bgcolor: "#FAFBFC",
              border: "1px solid",
              borderColor: "divider",
              fontSize: 12.5,
              color: "text.secondary",
            }}
          >
            No findings yet for this contract — run a review against one or more regulations to see
            highlighted clauses here.
          </Box>
        )}

        {doc.sections.map((section) => (
          <Box key={section.num} sx={{ mb: 2.75 }}>
            <Typography sx={{ fontFamily: "'Source Serif 4', serif", fontWeight: 600, fontSize: 14.5, mb: 0.9 }}>
              Article {section.num} — {section.heading}
            </Typography>

            {section.paragraphs.map((p, i) => (
              <Box
                key={i}
                sx={{
                  mb: 1.1,
                  fontSize: 13.25,
                  lineHeight: 1.7,
                  color: "text.primary",
                  ...(p.broken && {
                    bgcolor: "#E3F1E8",
                    borderLeft: "3px solid #3C7A5C",
                    borderRadius: "4px",
                    p: 1.25,
                  }),
                }}
              >
                {p.text}
              </Box>
            ))}
          </Box>
        ))}
      </DialogContent>
    </Dialog>
  );
}

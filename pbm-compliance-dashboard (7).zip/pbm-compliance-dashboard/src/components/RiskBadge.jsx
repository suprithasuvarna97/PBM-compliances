import Chip from "@mui/material/Chip";
import Box from "@mui/material/Box";
import { useTheme } from "@mui/material/styles";

const KEY_MAP = { High: "high", Moderate: "moderate", Low: "low" };

export default function RiskBadge({ level }) {
  const theme = useTheme();
  const c = theme.riskColors[KEY_MAP[level]];

  return (
    <Chip
      size="small"
      label={level}
      icon={
        <Box
          component="span"
          sx={{
            width: 7,
            height: 7,
            borderRadius: "50%",
            bgcolor: c.dot,
            ml: "8px !important",
          }}
        />
      }
      sx={{
        color: c.fg,
        backgroundColor: c.bg,
        "& .MuiChip-icon": { order: -1 },
      }}
    />
  );
}

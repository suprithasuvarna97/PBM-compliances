import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Tooltip from "@mui/material/Tooltip";

function scoreColor(score) {
  if (score >= 85) return { bg: "#DEEAE2", fg: "#2C5A41" }; // low risk / good
  if (score >= 65) return { bg: "#F5EAD7", fg: "#7A5417" }; // moderate
  return { bg: "#F6E4DF", fg: "#8A2E1F" }; // high risk
}

// Purely informational grid — rows = contracts, columns = regulations,
// each cell = that pair's compliance score. This is a breakdown view of
// the same aggregate data shown in the KPI cards/charts above; it doesn't
// select or filter anything (no click-through drill-down).
export default function ComplianceHeatmap({ contracts, regulations, matrix }) {
  return (
    <Box sx={{ overflowX: "auto" }}>
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: `180px repeat(${regulations.length}, minmax(120px, 1fr))`,
          gap: "6px",
          minWidth: 180 + regulations.length * 120,
        }}
      >
        <Box />
        {regulations.map((r) => (
          <Box key={r.id} sx={{ fontSize: 11, color: "text.secondary", textAlign: "center", px: 0.5, pb: 0.5 }}>
            {r.label.split("(")[0].trim()}
          </Box>
        ))}

        {contracts.map((c) => (
          <Box key={c.id} sx={{ display: "contents" }}>
            <Box sx={{ fontSize: 12.5, display: "flex", alignItems: "center", pr: 1, fontWeight: 500 }}>
              {c.label.split("—")[0].trim()}
            </Box>
            {regulations.map((r) => {
              const result = matrix[c.id]?.[r.id];
              const colors = result ? scoreColor(result.complianceScore) : { bg: "#F3F4F7", fg: "#8992A1" };
              return (
                <Tooltip
                  key={r.id}
                  title={result ? `${c.label} vs ${r.label} — ${result.violations.length} findings` : "Not yet run"}
                >
                  <Box
                    sx={{
                      height: 46,
                      borderRadius: "6px",
                      bgcolor: colors.bg,
                      color: colors.fg,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: 14,
                      fontWeight: 600,
                    }}
                  >
                    {result ? `${result.complianceScore}%` : "—"}
                  </Box>
                </Tooltip>
              );
            })}
          </Box>
        ))}
      </Box>
      <Typography sx={{ fontSize: 11, color: "#8992A1", mt: 1.25 }}>
        Breakdown of the score shown above, by contract–regulation pair.
      </Typography>
    </Box>
  );
}

import { useMemo } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import IconButton from "@mui/material/IconButton";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import { generateContractDocument } from "../data/generateContractText";

// Shows the contract's plain text with NO compliance analysis applied —
// this is meant to represent the raw document as originally selected or
// uploaded, before any review runs on it. "View output document" (the
// highlighted viewer) is the OUTCOME of analyzing this raw text; this is
// the input side of that same pipeline.
//
// Reuses generateContractDocument() with an empty violations list, so
// every article renders its neutral boilerplate text with nothing
// highlighted — same synthetic source as the analyzed viewer, since
// there's no real file content to read yet.
export default function RawDocumentViewerDialog({ open, onClose, contractLabel }) {
  const doc = useMemo(() => generateContractDocument(contractLabel, []), [contractLabel]);

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth scroll="paper">
      <DialogTitle sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", pr: 1.5 }}>
        <Box>
          <Typography sx={{ fontFamily: "'Source Serif 4', serif", fontSize: 17, fontWeight: 600 }}>
            {contractLabel}
          </Typography>
          <Typography sx={{ fontSize: 11.5, color: "text.secondary", fontWeight: 400 }}>
            Raw document text — shown as originally selected, before compliance analysis
          </Typography>
        </Box>
        <IconButton onClick={onClose} size="small">
          <CloseRoundedIcon fontSize="small" />
        </IconButton>
      </DialogTitle>

      <DialogContent dividers sx={{ fontFamily: "'IBM Plex Sans', sans-serif" }}>
        {doc.sections.map((section) => (
          <Box key={section.num} sx={{ mb: 2.75 }}>
            <Typography sx={{ fontFamily: "'Source Serif 4', serif", fontWeight: 600, fontSize: 14.5, mb: 0.9 }}>
              Article {section.num} — {section.heading}
            </Typography>
            {section.paragraphs.map((p, i) => (
              <Typography key={i} sx={{ mb: 1.1, fontSize: 13.25, lineHeight: 1.7, color: "text.primary" }}>
                {p.text}
              </Typography>
            ))}
          </Box>
        ))}
      </DialogContent>
    </Dialog>
  );
}

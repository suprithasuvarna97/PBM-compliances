import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";

export default function KpiCard({ icon, label, value, sub, tone }) {
  return (
    <Card
      variant="outlined"
      sx={{
        borderLeft: "3px solid",
        borderLeftColor: tone,
        borderRadius: "8px",
        height: "100%",
      }}
    >
      <CardContent sx={{ p: "15px 16px", "&:last-child": { pb: "15px" } }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 0.9, mb: 1.2, color: tone }}>
          {icon}
          <Typography sx={{ fontSize: 12, color: "text.secondary" }}>{label}</Typography>
        </Box>
        <Typography sx={{ fontFamily: "'Source Serif 4', serif", fontSize: 27, fontWeight: 600, lineHeight: 1 }}>
          {value}
        </Typography>
        {sub && (
          <Box sx={{ display: "flex", alignItems: "center", gap: 0.4, fontSize: 11.5, color: "#8992A1", mt: 0.8 }}>
            {sub}
          </Box>
        )}
      </CardContent>
    </Card>
  );
}

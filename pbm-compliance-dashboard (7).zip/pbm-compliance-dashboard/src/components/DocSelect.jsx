import { useRef } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import Checkbox from "@mui/material/Checkbox";
import ListItemText from "@mui/material/ListItemText";
import FormControl from "@mui/material/FormControl";
import IconButton from "@mui/material/IconButton";
import Tooltip from "@mui/material/Tooltip";
import InsertDriveFileRoundedIcon from "@mui/icons-material/InsertDriveFileRounded";
import UploadFileRoundedIcon from "@mui/icons-material/UploadFileRounded";

// Single- or multi-select over a pool of catalog + uploaded documents,
// with an upload button that adds straight into the pool + selection.
//
// Deliberately built on a plain MUI Select (not Autocomplete): values are
// always plain ids (or an array of ids for multi-select), which keeps
// "is this uploaded doc selected / visible" trivially easy to reason
// about — no object-identity comparisons that can silently misbehave.
//
//   multiple=false  -> value is a single id string,   onChange(id)
//   multiple=true   -> value is an array of id strings, onChange(idsArray)
export default function DocSelect({ label, pool, multiple, value, onChange, onUpload }) {
  const inputRef = useRef(null);

  const renderValue = (selected) => {
    if (multiple) {
      if (!selected || selected.length === 0) return <em style={{ fontStyle: "normal", color: "#8992A1" }}>None selected</em>;
      if (selected.length === 1) {
        const item = pool.find((p) => p.id === selected[0]);
        return item ? item.label : "";
      }
      return `${selected.length} selected`;
    }
    const item = pool.find((p) => p.id === selected);
    return item ? item.label : <em style={{ fontStyle: "normal", color: "#8992A1" }}>Select a document</em>;
  };

  return (
    <Box sx={{ display: "flex", flexDirection: "column", gap: 0.6, minWidth: multiple ? 300 : 260 }}>
      <Typography sx={{ fontSize: 11, color: "text.secondary" }}>{label}</Typography>
      <Box sx={{ display: "flex", gap: 0.75, alignItems: "center" }}>
        <FormControl size="small" sx={{ flex: 1 }}>
          <Select
            multiple={multiple}
            displayEmpty
            value={value}
            onChange={(e) => onChange(e.target.value)}
            renderValue={renderValue}
            sx={{
              fontSize: 12.5,
              bgcolor: "#FAFBFC",
              "& .MuiOutlinedInput-notchedOutline": { borderColor: "divider" },
            }}
          >
            {pool.map((p) => (
              <MenuItem key={p.id} value={p.id} sx={{ fontSize: 12.5 }}>
                {multiple && (
                  <Checkbox size="small" checked={value.includes(p.id)} sx={{ p: 0.5, mr: 0.25 }} />
                )}
                {p.isUpload && (
                  <InsertDriveFileRoundedIcon sx={{ fontSize: 15, mr: 0.75, color: "primary.main", flexShrink: 0 }} />
                )}
                <ListItemText primaryTypographyProps={{ fontSize: 12.5 }} primary={p.label} />
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        <Tooltip title="Upload a document">
          <IconButton
            size="small"
            onClick={() => inputRef.current?.click()}
            sx={{
              bgcolor: "#E7EEF5",
              color: "primary.main",
              borderRadius: "6px",
              border: "1px solid #D3E1EE",
              "&:hover": { bgcolor: "#DCE8F3" },
            }}
          >
            <UploadFileRoundedIcon sx={{ fontSize: 17 }} />
          </IconButton>
        </Tooltip>
        <input
          ref={inputRef}
          type="file"
          accept=".pdf,.doc,.docx,.txt"
          hidden
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) onUpload(f.name);
            e.target.value = "";
          }}
        />
      </Box>
    </Box>
  );
}

import Box from "@mui/material/Box";
import Tooltip from "@mui/material/Tooltip";
import { useTheme } from "@mui/material/styles";

// Compact "H:3  M:4  L:2" style summary used in the Vendor View table.
export default function AuditFindingsBadge({ findings }) {
  const theme = useTheme();

  if (!findings) {
    return (
      <Box component="span" sx={{ fontSize: 12, color: "#8992A1" }}>
        Not yet reviewed
      </Box>
    );
  }

  const items = [
    { key: "High", label: "H", count: findings.High, color: theme.riskColors.high.dot },
    { key: "Moderate", label: "M", count: findings.Moderate, color: theme.riskColors.moderate.dot },
    { key: "Low", label: "L", count: findings.Low, color: theme.riskColors.low.dot },
  ];

  return (
    <Box sx={{ display: "flex", gap: 1.5 }}>
      {items.map((it) => (
        <Tooltip key={it.key} title={`${it.key} risk findings`}>
          <Box sx={{ display: "flex", alignItems: "center", gap: 0.4, fontSize: 12.5 }}>
            <Box sx={{ width: 7, height: 7, borderRadius: "50%", bgcolor: it.color, flexShrink: 0 }} />
            <Box component="span" sx={{ fontWeight: 600 }}>
              {it.label}:
            </Box>
            {it.count}
          </Box>
        </Tooltip>
      ))}
    </Box>
  );
}

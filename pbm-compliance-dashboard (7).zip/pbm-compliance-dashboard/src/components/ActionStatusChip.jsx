import Box from "@mui/material/Box";
import Tooltip from "@mui/material/Tooltip";
import Chip from "@mui/material/Chip";
import { useTheme } from "@mui/material/styles";

// Shows the remediation status as a small colored chip, with the fuller
// detail text underneath (truncated by the cell's max-width) and also
// available as a tooltip on the chip itself.
export default function ActionStatusChip({ actionTaken }) {
  const theme = useTheme();
  if (!actionTaken) return null;
  const c = theme.statusColors[actionTaken.status];

  return (
    <Box>
      <Tooltip title={actionTaken.detail}>
        <Chip
          size="small"
          label={actionTaken.status}
          sx={{
            color: c?.fg,
            backgroundColor: c?.bg,
            mb: 0.5,
          }}
        />
      </Tooltip>
      <Box sx={{ fontSize: 12.5, color: "text.secondary", lineHeight: 1.45 }}>{actionTaken.detail}</Box>
    </Box>
  );
}

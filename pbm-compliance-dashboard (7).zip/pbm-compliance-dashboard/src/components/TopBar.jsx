import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import CircularProgress from "@mui/material/CircularProgress";
import Tooltip from "@mui/material/Tooltip";
import PlayArrowRoundedIcon from "@mui/icons-material/PlayArrowRounded";
import FolderOpenRoundedIcon from "@mui/icons-material/FolderOpenRounded";
import ArticleRoundedIcon from "@mui/icons-material/ArticleRounded";
import DescriptionRoundedIcon from "@mui/icons-material/DescriptionRounded";
import DocSelect from "./DocSelect";

export default function TopBar({
  title,
  subtitle,
  contractPool,
  selectedContractId,
  onChangeSelectedContract,
  onUploadContract,
  regulationPool,
  selectedRegulationIds,
  onChangeSelectedRegulations,
  onUploadRegulation,
  isAnalyzing,
  onRun,
  onOpenUploads,
  onViewActiveContract,
  onViewRawDocument,
  hasRunReview,
}) {
  const activeContract = contractPool.find((c) => c.id === selectedContractId);

  return (
    <Box
      sx={{
        bgcolor: "background.paper",
        borderBottom: "1px solid",
        borderColor: "divider",
      }}
    >
      <Box
        sx={{
          px: 3.5,
          pt: 2,
          pb: 1.5,
          display: "flex",
          alignItems: "flex-end",
          justifyContent: "space-between",
          gap: 2.5,
          flexWrap: "wrap",
        }}
      >
        <Box>
          <Typography variant="h5" sx={{ fontSize: 21, mb: 0.2 }}>
            {title}
          </Typography>
          <Typography sx={{ fontSize: 12.5, color: "text.secondary" }}>{subtitle}</Typography>
        </Box>

        <Box sx={{ display: "flex", gap: 1.75, alignItems: "flex-end", flexWrap: "wrap" }}>
          <DocSelect
            label="Contract"
            pool={contractPool}
            multiple={false}
            value={selectedContractId || ""}
            onChange={onChangeSelectedContract}
            onUpload={onUploadContract}
          />
          <DocSelect
            label="Regulations (checked together)"
            pool={regulationPool}
            multiple
            value={selectedRegulationIds}
            onChange={onChangeSelectedRegulations}
            onUpload={onUploadRegulation}
          />

          <Button
            variant="outlined"
            onClick={onOpenUploads}
            startIcon={<FolderOpenRoundedIcon sx={{ fontSize: 17 }} />}
            sx={{ fontSize: 13, px: 1.75, py: 1.05, borderColor: "divider", color: "text.primary" }}
          >
            View Uploads
          </Button>

          <Button
            variant="contained"
            disableElevation
            disabled={isAnalyzing}
            onClick={onRun}
            startIcon={
              isAnalyzing ? <CircularProgress size={14} color="inherit" /> : <PlayArrowRoundedIcon sx={{ fontSize: 18 }} />
            }
            sx={{ bgcolor: "#1B2233", "&:hover": { bgcolor: "#2A3450" }, px: 2, py: 1.1, fontSize: 13 }}
          >
            {isAnalyzing ? "Reviewing…" : "Run Review"}
          </Button>
        </Box>
      </Box>

      {/* Separate full-width strip — kept out of the control row above so
          its extra line never affects that row's alignment or wrapping. */}
      {activeContract && (
        <Box
          sx={{
            px: 3.5,
            pb: 1.25,
            display: "flex",
            alignItems: "center",
            gap: 1.5,
            flexWrap: "wrap",
          }}
        >
          <Typography sx={{ fontSize: 12, color: "text.secondary" }}>
            Selected contract: <strong>{activeContract.label}</strong>
          </Typography>

          <Tooltip title={hasRunReview ? "" : "Run a review first to load the output document"}>
            <span>
              <Button
                size="small"
                onClick={onViewActiveContract}
                disabled={!hasRunReview}
                startIcon={<ArticleRoundedIcon sx={{ fontSize: 15 }} />}
                sx={{ fontSize: 12, color: "primary.main", py: 0, minWidth: 0, "&:hover": { bgcolor: "transparent" } }}
              >
                View output document
              </Button>
            </span>
          </Tooltip>

          <Button
            size="small"
            onClick={onViewRawDocument}
            startIcon={<DescriptionRoundedIcon sx={{ fontSize: 15 }} />}
            sx={{ fontSize: 12, color: "primary.main", py: 0, minWidth: 0, "&:hover": { bgcolor: "transparent" } }}
          >
            View raw document
          </Button>
        </Box>
      )}
    </Box>
  );
}

import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import IconButton from "@mui/material/IconButton";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemText from "@mui/material/ListItemText";
import Button from "@mui/material/Button";
import Chip from "@mui/material/Chip";
import Divider from "@mui/material/Divider";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import InsertDriveFileRoundedIcon from "@mui/icons-material/InsertDriveFileRounded";

// Shows only documents the user actually UPLOADED (isUpload: true) — the
// built-in catalog entries are deliberately left out, since this dialog
// is meant to answer "what have I uploaded so far", not "what's available
// to pick from" (that's what the dropdown in the top bar is for).
export default function UploadsDialog({ open, onClose, contractPool, regulationPool, onViewContract }) {
  const uploadedContracts = contractPool.filter((c) => c.isUpload);
  const uploadedRegulations = regulationPool.filter((r) => r.isUpload);

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        Uploaded Documents
        <IconButton onClick={onClose} size="small">
          <CloseRoundedIcon fontSize="small" />
        </IconButton>
      </DialogTitle>
      <DialogContent dividers>
        <Typography sx={{ fontSize: 11.5, color: "text.secondary", textTransform: "uppercase", letterSpacing: 0.4, mb: 0.5 }}>
          Uploaded Contracts
        </Typography>
        {uploadedContracts.length === 0 ? (
          <Typography sx={{ fontSize: 12.5, color: "#8992A1", py: 1 }}>
            No contracts uploaded yet — use the Upload button next to "Contracts" in the top bar.
          </Typography>
        ) : (
          <List dense disablePadding>
            {uploadedContracts.map((c) => (
              <ListItem
                key={c.id}
                disableGutters
                secondaryAction={
                  <Button size="small" variant="outlined" onClick={() => onViewContract(c)}>
                    View
                  </Button>
                }
              >
                <ListItemText
                  primary={
                    <Box sx={{ display: "flex", alignItems: "center", gap: 0.6 }}>
                      <InsertDriveFileRoundedIcon sx={{ fontSize: 15, color: "primary.main" }} />
                      {c.label}
                    </Box>
                  }
                  primaryTypographyProps={{ fontSize: 13 }}
                  secondary={
                    <Chip
                      size="small"
                      label="Uploaded"
                      sx={{ mt: 0.4, height: 18, fontSize: 10.5, bgcolor: "#E7EEF5", color: "primary.main" }}
                    />
                  }
                />
              </ListItem>
            ))}
          </List>
        )}

        <Divider sx={{ my: 2 }} />

        <Typography sx={{ fontSize: 11.5, color: "text.secondary", textTransform: "uppercase", letterSpacing: 0.4, mb: 0.5 }}>
          Uploaded Regulations
        </Typography>
        {uploadedRegulations.length === 0 ? (
          <Typography sx={{ fontSize: 12.5, color: "#8992A1", py: 1 }}>
            No regulation documents uploaded yet — use the Upload button next to "Regulations" in the top bar.
          </Typography>
        ) : (
          <List dense disablePadding>
            {uploadedRegulations.map((r) => (
              <ListItem key={r.id} disableGutters>
                <ListItemText
                  primary={
                    <Box sx={{ display: "flex", alignItems: "center", gap: 0.6 }}>
                      <InsertDriveFileRoundedIcon sx={{ fontSize: 15, color: "primary.main" }} />
                      {r.label}
                    </Box>
                  }
                  primaryTypographyProps={{ fontSize: 13 }}
                  secondary={
                    <Chip
                      size="small"
                      label="Uploaded"
                      sx={{ mt: 0.4, height: 18, fontSize: 10.5, bgcolor: "#E7EEF5", color: "primary.main" }}
                    />
                  }
                />
              </ListItem>
            ))}
          </List>
        )}
      </DialogContent>
    </Dialog>
  );
}

import Button from "@mui/material/Button";
import NotificationsNoneRoundedIcon from "@mui/icons-material/NotificationsNoneRounded";
import CheckRoundedIcon from "@mui/icons-material/CheckRounded";

// Per-row "Notify" action. Clicking it flips its own label/state to
// "Notified" — purely client-side for now (no backend call yet); wire
// this up to a real notification endpoint when one exists.
export default function NotifyButton({ notified, onToggle }) {
  return (
    <Button
      size="small"
      variant={notified ? "text" : "outlined"}
      disabled={notified}
      onClick={onToggle}
      startIcon={
        notified ? (
          <CheckRoundedIcon sx={{ fontSize: 15 }} />
        ) : (
          <NotificationsNoneRoundedIcon sx={{ fontSize: 15 }} />
        )
      }
      sx={{
        fontSize: 12,
        py: 0.4,
        whiteSpace: "nowrap",
        color: notified ? "#3C7A5C" : undefined,
        "&.Mui-disabled": { color: "#3C7A5C" },
      }}
    >
      {notified ? "Notified" : "Notify"}
    </Button>
  );
}

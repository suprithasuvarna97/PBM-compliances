import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import Box from "@mui/material/Box";

export default function CategoryBarChart({ data }) {
  return (
    <Box sx={{ height: 240 }}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ left: 8, right: 16 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#EEF0F3" horizontal={false} />
          <XAxis type="number" tick={{ fontSize: 11, fill: "#8992A1" }} allowDecimals={false} />
          <YAxis type="category" dataKey="name" width={70} tick={{ fontSize: 11.5, fill: "#5B6472" }} />
          <Tooltip
            formatter={(v, n, p) => [v, p.payload.fullName]}
            contentStyle={{ fontSize: 12, borderRadius: 6, border: "1px solid #E1E4EA" }}
          />
          <Bar dataKey="count" fill="#2F5D8C" radius={[0, 4, 4, 0]} barSize={16} />
        </BarChart>
      </ResponsiveContainer>
    </Box>
  );
}

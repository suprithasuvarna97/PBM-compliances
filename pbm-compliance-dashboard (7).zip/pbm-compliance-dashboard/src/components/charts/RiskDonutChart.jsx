import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";
import Box from "@mui/material/Box";
import { useTheme } from "@mui/material/styles";

export default function RiskDonutChart({ riskCounts }) {
  const theme = useTheme();
  const data = [
    { name: "High", value: riskCounts.High, dot: theme.riskColors.high.dot },
    { name: "Moderate", value: riskCounts.Moderate, dot: theme.riskColors.moderate.dot },
    { name: "Low", value: riskCounts.Low, dot: theme.riskColors.low.dot },
  ].filter((d) => d.value > 0);

  return (
    <>
      <Box sx={{ display: "flex", gap: 1.75, justifyContent: "center", flexWrap: "wrap", mb: 0.5 }}>
        {data.map((d) => (
          <Box key={d.name} sx={{ display: "flex", alignItems: "center", gap: 0.7, fontSize: 12, color: "text.secondary" }}>
            <Box sx={{ width: 8, height: 8, borderRadius: "2px", bgcolor: d.dot }} />
            {d.name} ({d.value})
          </Box>
        ))}
      </Box>
      <Box sx={{ height: 210 }}>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie data={data} dataKey="value" nameKey="name" innerRadius={52} outerRadius={80} paddingAngle={3}>
              {data.map((d) => (
                <Cell key={d.name} fill={d.dot} stroke="none" />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </Box>
    </>
  );
}

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import Box from "@mui/material/Box";

export default function TrendLineChart({ data }) {
  return (
    <Box sx={{ height: 200 }}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ left: -14, right: 16, top: 6 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#EEF0F3" vertical={false} />
          <XAxis dataKey="cycle" tick={{ fontSize: 11, fill: "#8992A1" }} />
          <YAxis domain={[30, 100]} tick={{ fontSize: 11, fill: "#8992A1" }} />
          <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6, border: "1px solid #E1E4EA" }} />
          <Line type="monotone" dataKey="score" stroke="#2F5D8C" strokeWidth={2.25} dot={{ r: 3.5, fill: "#2F5D8C" }} />
        </LineChart>
      </ResponsiveContainer>
    </Box>
  );
}

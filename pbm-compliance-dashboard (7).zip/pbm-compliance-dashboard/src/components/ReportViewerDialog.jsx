import { useMemo } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import IconButton from "@mui/material/IconButton";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Typography from "@mui/material/Typography";
import Divider from "@mui/material/Divider";
import Chip from "@mui/material/Chip";
import Button from "@mui/material/Button";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import PrintRoundedIcon from "@mui/icons-material/PrintRounded";
import { generateContractDocument } from "../data/generateContractText";
import RiskBadge from "./RiskBadge";
import ActionStatusChip from "./ActionStatusChip";
import AuditFindingsBadge from "./AuditFindingsBadge";

function scoreColor(score) {
  if (score == null) return { bg: "#EEF0F3", fg: "#5B6472" };
  if (score >= 85) return { bg: "#DEEAE2", fg: "#2C5A41" };
  if (score >= 65) return { bg: "#F5EAD7", fg: "#7A5417" };
  return { bg: "#F6E4DF", fg: "#8A2E1F" };
}

// The full audit-style report, used by Vendor View's "View Report":
// an executive summary (score, risk breakdown, regulations checked), a
// quick-jump findings list, then the full contract text with every broken
// clause highlighted — each tagged with its risk level, which regulation
// it breaks, its current remediation status, and the impact analysis with
// a link to real supporting evidence. Printable via the button in the
// header (isolates just the report content, not the surrounding app UI).
export default function ReportViewerDialog({
  open,
  onClose,
  contractLabel,
  vendorName,
  department,
  complianceScore,
  findings,
  regulations = [],
  violations = [],
}) {
  const doc = useMemo(() => generateContractDocument(contractLabel, violations), [contractLabel, violations]);
  const scoreC = scoreColor(complianceScore);
  const generatedOn = useMemo(
    () => new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" }),
    [open]
  );

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth scroll="paper">
      <style>{`
        @media print {
          body * { visibility: hidden; }
          #compliance-report-print, #compliance-report-print * { visibility: visible; }
          #compliance-report-print { position: absolute; left: 0; top: 0; width: 100%; }
          .no-print { display: none !important; }
        }
      `}</style>

      <DialogTitle sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", pr: 1.5 }}>
        <Typography sx={{ fontFamily: "'Source Serif 4', serif", fontSize: 17, fontWeight: 600 }}>
          Compliance Report
        </Typography>
        <Box className="no-print" sx={{ display: "flex", gap: 0.5 }}>
          <IconButton onClick={() => window.print()} size="small" title="Print or save as PDF">
            <PrintRoundedIcon fontSize="small" />
          </IconButton>
          <IconButton onClick={onClose} size="small">
            <CloseRoundedIcon fontSize="small" />
          </IconButton>
        </Box>
      </DialogTitle>

      <DialogContent dividers id="compliance-report-print" sx={{ fontFamily: "'IBM Plex Sans', sans-serif" }}>
        {/* ---- Executive summary ---- */}
        <Box sx={{ mb: 2.5 }}>
          <Typography sx={{ fontFamily: "'Source Serif 4', serif", fontSize: 20, fontWeight: 600, mb: 0.3 }}>
            {vendorName || contractLabel}
          </Typography>
          <Typography sx={{ fontSize: 12.5, color: "text.secondary", mb: department ? 0.2 : 0 }}>
            {contractLabel}
          </Typography>
          {department && (
            <Typography sx={{ fontSize: 12, color: "text.secondary" }}>{department}</Typography>
          )}
          <Typography sx={{ fontSize: 11, color: "#8992A1", mt: 0.5 }}>Generated {generatedOn}</Typography>
        </Box>

        <Grid container spacing={1.5} sx={{ mb: 2 }}>
          <Grid item xs={12} sm={4}>
            <Box sx={{ border: "1px solid", borderColor: "divider", borderRadius: "8px", p: 1.5, height: "100%" }}>
              <Typography sx={{ fontSize: 11, color: "text.secondary", mb: 0.5 }}>Compliance Score</Typography>
              <Box
                sx={{
                  display: "inline-flex",
                  alignItems: "baseline",
                  gap: 0.5,
                  bgcolor: scoreC.bg,
                  color: scoreC.fg,
                  borderRadius: "6px",
                  px: 1,
                  py: 0.3,
                }}
              >
                <Typography sx={{ fontFamily: "'Source Serif 4', serif", fontSize: 24, fontWeight: 600 }}>
                  {complianceScore != null ? `${complianceScore}%` : "—"}
                </Typography>
              </Box>
            </Box>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Box sx={{ border: "1px solid", borderColor: "divider", borderRadius: "8px", p: 1.5, height: "100%" }}>
              <Typography sx={{ fontSize: 11, color: "text.secondary", mb: 0.5 }}>Total Findings</Typography>
              <Typography sx={{ fontFamily: "'Source Serif 4', serif", fontSize: 24, fontWeight: 600 }}>
                {violations.length}
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Box sx={{ border: "1px solid", borderColor: "divider", borderRadius: "8px", p: 1.5, height: "100%" }}>
              <Typography sx={{ fontSize: 11, color: "text.secondary", mb: 0.9 }}>Risk Breakdown</Typography>
              <AuditFindingsBadge findings={findings} />
            </Box>
          </Grid>
        </Grid>

        {regulations.length > 0 && (
          <Box sx={{ mb: 2.5 }}>
            <Typography sx={{ fontSize: 11, color: "text.secondary", mb: 0.6 }}>Checked against</Typography>
            <Box sx={{ display: "flex", gap: 0.6, flexWrap: "wrap" }}>
              {regulations.map((r) => (
                <Chip key={r.id} size="small" label={r.label.split("(")[0].trim()} sx={{ fontSize: 11.5, bgcolor: "#EEF0F3" }} />
              ))}
            </Box>
          </Box>
        )}

        {/* ---- Quick-jump findings list ---- */}
        {violations.length > 0 && (
          <>
            <Divider sx={{ mb: 1.5 }} />
            <Typography sx={{ fontFamily: "'Source Serif 4', serif", fontSize: 14.5, fontWeight: 600, mb: 1 }}>
              Findings at a Glance
            </Typography>
            <Box sx={{ mb: 2.5 }}>
              {violations.map((v) => (
                <Box
                  key={v.id}
                  component="a"
                  href={`#finding-${v.id}`}
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    gap: 1,
                    py: 0.6,
                    textDecoration: "none",
                    color: "inherit",
                    borderBottom: "1px solid",
                    borderColor: "#EEF0F3",
                    "&:hover": { bgcolor: "#FAFBFC" },
                  }}
                >
                  <RiskBadge level={v.risk} />
                  <Typography sx={{ fontSize: 12, fontWeight: 500, whiteSpace: "nowrap" }}>{v.id}</Typography>
                  <Typography sx={{ fontSize: 12.5, color: "text.secondary", flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    {v.category}
                  </Typography>
                </Box>
              ))}
            </Box>
          </>
        )}

        {violations.length === 0 && (
          <Box
            sx={{
              mb: 2.5,
              p: 1.5,
              borderRadius: "6px",
              bgcolor: "#FAFBFC",
              border: "1px solid",
              borderColor: "divider",
              fontSize: 12.5,
              color: "text.secondary",
            }}
          >
            No findings yet for this vendor — run a review against one or more regulations to generate
            this report.
          </Box>
        )}

        {/* ---- Full contract text ---- */}
        <Divider sx={{ mb: 1.5 }} />
        <Typography sx={{ fontFamily: "'Source Serif 4', serif", fontSize: 14.5, fontWeight: 600, mb: 1.25 }}>
          Full Contract Text
        </Typography>

        {doc.sections.map((section) => (
          <Box key={section.num} sx={{ mb: 2.75 }}>
            <Typography sx={{ fontFamily: "'Source Serif 4', serif", fontWeight: 600, fontSize: 14.5, mb: 0.9 }}>
              Article {section.num} — {section.heading}
            </Typography>

            {section.paragraphs.map((p, i) => (
              <Box
                key={i}
                id={p.broken ? `finding-${p.meta.id}` : undefined}
                sx={{
                  mb: 1.1,
                  fontSize: 13.25,
                  lineHeight: 1.7,
                  color: "text.primary",
                  scrollMarginTop: "16px",
                  ...(p.broken && {
                    bgcolor: "#E3F1E8",
                    borderLeft: "3px solid #3C7A5C",
                    borderRadius: "4px",
                    p: 1.25,
                  }),
                }}
              >
                {p.text}
                {p.broken && (
                  <Box sx={{ mt: 0.9, display: "flex", flexDirection: "column", gap: 0.9 }}>
                    <Box sx={{ display: "flex", gap: 1, flexWrap: "wrap", alignItems: "center" }}>
                      <RiskBadge level={p.meta.risk} />
                      <Typography sx={{ fontSize: 11.5, color: "text.secondary" }}>
                        Breaks {p.meta.regulation} · {p.meta.id}
                      </Typography>
                    </Box>
                    <ActionStatusChip actionTaken={p.meta.actionTaken} />
                    {p.meta.remediation && (
                      <Box sx={{ fontSize: 12, color: "text.secondary", borderTop: "1px dashed #C8DBCE", pt: 0.75 }}>
                        <Box component="span" sx={{ fontWeight: 600, color: "text.primary" }}>
                          Recommended Fix:{" "}
                        </Box>
                        {p.meta.remediation}
                      </Box>
                    )}
                  </Box>
                )}
              </Box>
            ))}
          </Box>
        ))}
      </DialogContent>
    </Dialog>
  );
}

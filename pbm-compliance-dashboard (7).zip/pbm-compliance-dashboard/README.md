# Sentinel Rx — PBM Compliance Review Dashboard

A React + Material UI dashboard for reviewing **one contract against
multiple regulations, checked together** ("Option A"), plus a portfolio-
level Vendor View across every contract in the pool. No backend is wired
up yet — everything is generated client-side so the UI can be built and
demoed end to end.

## Project structure

```
sentinel-rx/
├─ index.html
├─ vite.config.js
├─ package.json
└─ src/
   ├─ main.jsx                    # React root, MUI ThemeProvider
   ├─ App.jsx                     # Owns selection + the shared matrix, layout, dialogs
   ├─ theme.js                    # MUI theme: palette, risk + status colors
   ├─ data/
   │  ├─ catalog.js                # Dropdown options, vendor metadata, regulation links, finding templates
   │  ├─ generateAnalysis.js       # Mock "LLM" output for one contract × one regulation
   │  ├─ generateContractText.js   # Synthetic full contract text (for the document viewer)
   │  ├─ aggregateMatrix.js        # Sums/averages results across a set of pairs (Overview)
   │  └─ buildVendorRows.js        # Per-contract rollup across regulations (Vendor View)
   ├─ hooks/
   │  └─ useMatrixAnalysis.js      # THE data source — runs generateAnalysis for every contract × regulation pair
   ├─ components/
   │  ├─ Sidebar.jsx, TopBar.jsx
   │  ├─ DocSelect.jsx             # Single- or multi-select + upload (Contract uses single, Regulations uses multi)
   │  ├─ UploadsDialog.jsx         # "View Uploads" — uploaded docs ONLY, View button per contract
   │  ├─ DocumentViewerDialog.jsx  # Full contract text, green-highlighted broken clauses
   │  ├─ ComplianceHeatmap.jsx     # Score breakdown, one row (contract) × N columns (regulations)
   │  ├─ KpiCard.jsx, RiskBadge.jsx, ActionStatusChip.jsx, AuditFindingsBadge.jsx
   │  └─ charts/ (RiskDonutChart, CategoryBarChart, TrendLineChart)
   └─ pages/
      ├─ Overview.jsx              # KPI cards + charts for the active contract vs. all selected regulations
      ├─ ViolationLog.jsx          # Every finding for the active contract, filterable by regulation/risk
      └─ VendorView.jsx            # Every contract in the pool, each vs. the same selected regulations
```

## Run it

```bash
npm install
npm run dev
```

Then open the URL Vite prints (usually `http://localhost:5173`).

## The data model ("Option A")

- **Contract**: single-select. One contract is "active" at a time.
- **Regulations**: multi-select. All selected regulations are checked
  **together** against the active contract.
- Clicking **Run Review** bumps `runNonce`. `useMatrixAnalysis` then runs
  `generateAnalysis()` for **every contract in the pool** (not just the
  active one) × every selected regulation, and stores it as
  `matrix[contractId][regulationId]`.
- **Overview** and **Violation Log** read `matrix` filtered to just the
  active contract, aggregated across the selected regulations.
- **Vendor View** reads the *same* `matrix`, but shows every contract's
  row — so a given contract's numbers are identical whether you're
  looking at it via Overview or via its row in Vendor View, because
  they're the same underlying data.
- The **document viewer** (opened from "View Uploads") also reads
  straight from `matrix[contractId]`, so it works for any contract in the
  pool, not just the currently active one.

This "one matrix, several views into it" design is what keeps everything
in sync — there's a single hook call in `App.jsx`, and every page is just
a different filter/aggregation over its result.

## Fixed: uploaded documents not appearing

The previous version used MUI `Autocomplete` for both pickers. After not
being able to find a logic bug through code review, and given
`Autocomplete`'s heavier reliance on object-identity comparisons (and
sensitivity to exact MUI minor-version behavior), it was replaced with
`DocSelect.jsx` — a single component built on a plain MUI `Select`
(`multiple` prop for Regulations, single value for Contract). Values are
always plain string ids, which removes an entire class of "why isn't this
showing up" bugs. If uploads still don't appear after this change, that
points to something more specific (e.g. a MUI version pulled by `npm
install` behaving differently) — let me know exactly what you see
(nothing added to the dropdown at all? added but not shown in "View
Uploads"? console errors?) and I can narrow it down further.

## The document viewer (green highlights)

There's no real PDF/DOCX text extraction wired up — an uploaded file
today is just a filename, its content is never read. `generateContractText.js`
builds a **synthetic** but structurally realistic contract (numbered
articles) and slots each violation's finding text into the article that
matches its category, flagging that paragraph as `broken: true`.
`DocumentViewerDialog` renders the full text and highlights those
paragraphs in green (per your original request — note this is the
opposite of the red/amber/green convention used elsewhere in the app; a
one-line color change in that file's `p.broken` style block switches it
to amber/red if that reads better next to the risk badges).

## Vendor View

Columns: **Vendor Name, Contract, Department, Risk, Compliance Score,
Audit Findings** (shown as `H:3  M:4  L:2`). Vendor name and department
come from `VENDOR_META` in `catalog.js` (falls back to the filename +
"Unassigned" for uploaded contracts without a catalog entry). Risk,
score, and audit findings are computed by `buildVendorRows.js` from the
same `matrix` every other page reads — nothing here is independently
randomized.

## Wiring up a real backend later

Replace the body of the `useEffect` in `src/hooks/useMatrixAnalysis.js`
with a real API call (per pair, or one batched call returning the whole
matrix). As long as each result has the same shape as `generateAnalysis()`
returns (`totalClauses`, `violations[]`, `riskCounts`, `categoryBreakdown`,
`complianceScore`, `trend`, `timestamp`), nothing else in the app needs to
change — Overview, Violation Log, Vendor View, and the document viewer all
consume that same shape through `aggregateMatrix.js` / `buildVendorRows.js`.

## Recent changes: Gap/Impact Analysis, raw document view, vendor reports

- **Top bar layout fix**: "View this document" (and the new "View raw
  document") live in their own full-width strip below the main control
  row, not nested inside it — an earlier version nested the link inside
  the Contract control, which made that flex item taller than its
  siblings and broke the row's alignment/wrapping.
- **"View raw document"** (`RawDocumentViewerDialog.jsx`) shows the same
  synthetic contract text with zero highlighting — meant to represent the
  document *before* analysis, as a contrast to the highlighted "outcome"
  view. It's disabled until "Run Review" has been clicked at least once
  (`hasRunReview` state in `App.jsx`).
- **Violation Log columns renamed**: "Finding" → **Gap Analysis** (now
  written as an explicit contract-vs-regulation contrast, with the
  regulation's public source link shown inline underneath the text
  instead of in its own column); "Recommended Action" → **Impact
  Analysis** (rewritten to describe the consequence of the gap, not a
  fix — the `recommendation` field was renamed to `impactAnalysis`
  throughout). "Action Taken" and the standalone "Reference Link" column
  are hidden for now (data still exists, just not rendered — see below).
- **Vendor View**: Risk column replaced with a **View Report** button
  (tooltip shows the risk level on hover). Clicking it opens the same
  `DocumentViewerDialog` used by "View this document" — this is the
  "fully-fledged report": full contract text, broken clauses highlighted
  green, each tagged with its risk badge, which regulation it breaks, and
  its current **Action Taken** status (this is where the hidden column's
  data resurfaces — in context, next to the actual clause, rather than as
  a flat table column).

## Corrections: enable/disable swap, viewer split, plain-language content, real impact links

- **Enable/disable swapped** (was backwards): "View raw document" is now
  always available; "View output document" is disabled until "Run
  Review" has been clicked at least once (`hasRunReview` in `App.jsx`).
- **Two separate viewers, not one**: `DocumentViewerDialog.jsx` ("View
  output document") now shows ONLY the green highlight on broken text —
  no risk badge, no regulation name, no action-taken status. A new
  `ReportViewerDialog.jsx` — used by Vendor View's **View Report** — shows
  the fuller picture: highlight + risk badge + which regulation it breaks
  + current Action Taken status, per finding.
- **Gap Analysis / Impact Analysis content rewritten in plain language.**
  Gap Analysis = what's different or missing between the contract and the
  regulation. Impact Analysis = what could actually happen as a result.
  Every one of the 13 finding templates in `catalog.js` was rewritten to
  fit that distinction plainly (e.g. "The contract only reports rebates in
  one lump sum... The regulation requires rebates to be reported
  separately for each plan sponsor" / "The plan sponsor can't verify it
  received the rebate amount it's owed, which can lead to a CMS audit
  finding and clawback").
- **Link moved from Gap Analysis to Impact Analysis**, and it's now a
  *different, real, verified* source than before — not the regulation's
  own text (that's still used for the Source link in "View Uploads"), but
  a live page documenting actual enforcement/consequences for that
  category, added as `IMPACT_LINKS` in `catalog.js`:
  - Rebates / formulary / claims / audit categories →
    CMS's Part C & D Compliance Actions page (real warning letters and
    corrective action plans)
  - Privacy → HHS OCR's HIPAA Enforcement Highlights page (real
    settlement/penalty totals)
  - Pricing & spread → the FTC's Pharmacy Benefit Managers report (its
    actual spread-pricing findings)
  - Network adequacy / reporting → CMS's Part C & D Compliance and Audits
    overview
  - Audit rights → CMS's Part C & D Program Audit Results page
  
  All five were verified live via search before being hardcoded — not
  guessed.

## Vendor View: filters + a genuinely useful report

- **Filters added** to Vendor View: Risk (toggle buttons), Department
  (dropdown, populated from whatever's actually in the pool), and a
  search box across vendor/contract/department — same interaction
  pattern as Violation Log's filters, for consistency.
- **"View Report" redesigned** (`ReportViewerDialog.jsx`) — it's now an
  actual report, not just highlighted text in a dialog:
  - **Executive summary** at the top: vendor name, contract, department,
    generated date, compliance score (color-coded), total findings count,
    risk breakdown (H/M/L), and which regulations were checked (as chips)
  - **"Findings at a Glance"** — a compact clickable list of every
    finding; clicking one jumps straight to that clause further down in
    the full text (anchor-based, works inside the scrollable dialog)
  - **Richer highlighted clauses** — each broken paragraph now also shows
    its Impact Analysis text with a link to real supporting evidence
    (previously only risk + regulation + action taken)
  - **Print / Save as PDF** button — uses the browser's native print
    dialog, with print CSS that isolates just the report content (so the
    printed/saved output doesn't include the rest of the app's UI chrome)
  - All of this data (score, findings, department) is passed in from the
    same `buildVendorRows()` result the Vendor View table already shows,
    so the report's numbers always match that row exactly.

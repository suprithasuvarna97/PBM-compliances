import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import List from "@mui/material/List";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import Typography from "@mui/material/Typography";
import Divider from "@mui/material/Divider";
import ShieldRoundedIcon from "@mui/icons-material/ShieldRounded";
import GridViewRoundedIcon from "@mui/icons-material/GridViewRounded";
import TableChartRoundedIcon from "@mui/icons-material/TableChartRounded";
import StorefrontRoundedIcon from "@mui/icons-material/StorefrontRounded";
import PeopleAltRoundedIcon from "@mui/icons-material/PeopleAltRounded";
import AssignmentIndRoundedIcon from "@mui/icons-material/AssignmentIndRounded";

export const SIDEBAR_WIDTH = 216;

const NAV_ITEMS = [
  { key: "overview", label: "Overview", icon: <GridViewRoundedIcon fontSize="small" /> },
  { key: "table", label: "Violation Log", icon: <TableChartRoundedIcon fontSize="small" /> },
  { key: "vendors", label: "Vendor View", icon: <StorefrontRoundedIcon fontSize="small" /> },
  { key: "clients", label: "Client View", icon: <PeopleAltRoundedIcon fontSize="small" /> },
  { key: "licenses", label: "Licence Contract Status", icon: <AssignmentIndRoundedIcon fontSize="small" /> },
];

export default function Sidebar({ activeTab, onChangeTab }) {
  return (
    <Drawer
      variant="permanent"
      sx={{
        width: SIDEBAR_WIDTH,
        flexShrink: 0,
        "& .MuiDrawer-paper": {
          width: SIDEBAR_WIDTH,
          boxSizing: "border-box",
          bgcolor: "#171E2E",
          color: "#C7CDDB",
          border: "none",
          p: 2,
          display: "flex",
          flexDirection: "column",
        },
      }}
    >
      <Box sx={{ display: "flex", alignItems: "center", gap: 1.2, px: 0.5, mb: 3 }}>
        <Box
          sx={{
            width: 28,
            height: 28,
            borderRadius: "7px",
            background: "linear-gradient(155deg, #3E6C99, #22405E)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "#fff",
            flexShrink: 0,
          }}
        >
          <ShieldRoundedIcon sx={{ fontSize: 16 }} />
        </Box>
        <Box>
          <Typography sx={{ fontFamily: "'Source Serif 4', serif", fontSize: 16.5, color: "#fff", lineHeight: 1.1 }}>
            Sentinel Rx
          </Typography>
          <Typography sx={{ fontSize: 10.5, color: "#8792A8" }}>PBM Compliance Review</Typography>
        </Box>
      </Box>

      <List sx={{ py: 0 }}>
        {NAV_ITEMS.map((item) => {
          const active = activeTab === item.key;
          return (
            <ListItemButton
              key={item.key}
              onClick={() => onChangeTab(item.key)}
              sx={{
                borderRadius: "7px",
                mb: 0.3,
                borderLeft: "2px solid",
                borderLeftColor: active ? "#6E9BC7" : "transparent",
                bgcolor: active ? "#22314A" : "transparent",
                color: active ? "#fff" : "#C7CDDB",
                "&:hover": { bgcolor: active ? "#22314A" : "#1F273B" },
              }}
            >
              <ListItemIcon sx={{ minWidth: 32, color: "inherit" }}>{item.icon}</ListItemIcon>
              <ListItemText primaryTypographyProps={{ fontSize: 13.5 }} primary={item.label} />
            </ListItemButton>
          );
        })}
      </List>

      <Box sx={{ mt: "auto" }}>
        <Divider sx={{ borderColor: "#2A3348", mb: 1.75 }} />
        <Typography sx={{ fontSize: 11, color: "#6B7690", lineHeight: 1.5 }}>
          Findings are generated from the selected contract and regulatory
          reference by the review model. Verify before relying on results
          for filing or remediation.
        </Typography>
      </Box>
    </Drawer>
  );
}

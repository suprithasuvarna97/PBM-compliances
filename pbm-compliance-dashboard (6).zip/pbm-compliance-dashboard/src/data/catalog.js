// Static reference catalog — in the real system these lists would come
// from a documents/regulations API instead of being hardcoded.

export const CONTRACT_DOCS = [
  "Meridian Health — PBM Master Services Agreement (FY26)",
  "Horizon Rx Network — Pharmacy Services Contract",
  "Statewide Medicaid PBM Agreement — Dept. of Health & Human Services",
  "Acme Industries — Employer Group Rx Benefit Contract",
];

export const REFERENCE_DOCS = [
  "CMS Medicare Part D Regulations (42 CFR § 423)",
  "ERISA Fiduciary Duty Standards (29 U.S.C. § 1104)",
  "NCPDP Telecommunication & SCRIPT Standards",
  "State PBM Licensing & Transparency Act",
  "340B Drug Pricing Program Rules (42 U.S.C. § 256b)",
];

// Public source link for each catalog regulation — used for the
// "Reference Link" column so a reviewer can jump straight to the source.
// Uploaded documents won't have an entry here on purpose: the UI falls
// back to an "internal document, no public link" note in that case.
export const REFERENCE_LINKS = {
  "CMS Medicare Part D Regulations (42 CFR § 423)":
    "https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-B/part-423",
  "ERISA Fiduciary Duty Standards (29 U.S.C. § 1104)":
    "https://www.law.cornell.edu/uscode/text/29/1104",
  "NCPDP Telecommunication & SCRIPT Standards": "https://standards.ncpdp.org/",
  "State PBM Licensing & Transparency Act":
    "https://www.ncsl.org/health/pharmacy-benefit-managers",
  "340B Drug Pricing Program Rules (42 U.S.C. § 256b)": "https://www.hrsa.gov/opa",
};

export const CATEGORIES = [
  { code: "REB", name: "Rebate Pass-Through & Aggregation" },
  { code: "FOR", name: "Formulary Placement & Management" },
  { code: "NET", name: "Network Adequacy & Pharmacy Access" },
  { code: "PRV", name: "Data Privacy & Security" },
  { code: "PRC", name: "Pricing & Spread Transparency" },
  { code: "CLM", name: "Claims Adjudication Accuracy" },
  { code: "RPT", name: "Reporting & Disclosure Obligations" },
  { code: "AUD", name: "Audit & Inspection Rights" },
];

// Vendor metadata for each catalog contract — used by the Vendor View tab
// to show a proper vendor name and owning department instead of the raw
// contract title. Uploaded contracts won't have an entry here on purpose;
// getVendorMeta() falls back to something reasonable for those.
export const VENDOR_META = {
  "Meridian Health — PBM Master Services Agreement (FY26)": {
    vendor: "Meridian Health",
    department: "Pharmacy Operations",
  },
  "Horizon Rx Network — Pharmacy Services Contract": {
    vendor: "Horizon Rx Network",
    department: "Network Management",
  },
  "Statewide Medicaid PBM Agreement — Dept. of Health & Human Services": {
    vendor: "State DHHS Medicaid Program",
    department: "Government Programs",
  },
  "Acme Industries — Employer Group Rx Benefit Contract": {
    vendor: "Acme Industries",
    department: "Employer Benefits",
  },
};

export function getVendorMeta(contractLabel) {
  return VENDOR_META[contractLabel] || { vendor: contractLabel.replace(/\.[^/.]+$/, ""), department: "Unassigned" };
}

// Each template: d = finding description, r = recommended action,
// a = { status, detail } describing what's actually been done about it
// so far (this is the "Action Taken" column — status of remediation,
// not what *should* be done, which is `r`).
export const TEMPLATES = {
  REB: [
    {
      d: "Manufacturer rebate share owed to plan sponsor is not passed through within the contractual settlement window.",
      r: "Amend Section 4 to define a fixed rebate remittance schedule tied to quarter-end close.",
      a: { status: "Escalated", detail: "Sent to legal for contract amendment; response due in 15 business days." },
    },
    {
      d: "Aggregated rebate revenue is reported at the book-of-business level rather than per-plan, obscuring sponsor-level entitlement.",
      r: "Require per-plan rebate ledgers reconciled against manufacturer remittance statements.",
      a: { status: "In Progress", detail: "Finance is rebuilding rebate ledgers at the per-plan level." },
    },
  ],
  FOR: [
    {
      d: "Formulary tier placement favors rebate-generating brand products over lower net-cost generics for the same indication.",
      r: "Introduce a net-cost review step before any tier placement change takes effect.",
      a: { status: "Not Started", detail: "Flagged to P&T committee; no review scheduled yet." },
    },
    {
      d: "P&T committee formulary decisions are not documented with clinical rationale as required.",
      r: "Mandate meeting minutes and written rationale for every formulary determination.",
      a: { status: "Resolved", detail: "Minutes template updated and adopted starting last committee cycle." },
    },
  ],
  NET: [
    {
      d: "Rural service area pharmacy density falls below the minimum access standard for maintenance medications.",
      r: "Add network adequacy reporting by ZIP code with a remediation trigger below threshold.",
      a: { status: "In Progress", detail: "Network team sourcing two additional rural pharmacy partners." },
    },
  ],
  PRV: [
    {
      d: "Claims data sharing with an affiliated analytics entity lacks a documented minimum-necessary determination.",
      r: "Execute a data use agreement scoping fields to the minimum necessary for the stated purpose.",
      a: { status: "Escalated", detail: "Referred to privacy officer; data sharing paused pending review." },
    },
    {
      d: "Member PHI retention period exceeds the limit specified in the reference standard without a documented exception.",
      r: "Align retention schedule to policy and log any exception with an expiration date.",
      a: { status: "Not Started", detail: "No remediation owner assigned yet." },
    },
  ],
  PRC: [
    {
      d: "Spread pricing between pharmacy reimbursement and plan sponsor billing is not disclosed in the quarterly reporting package.",
      r: "Add a spread disclosure line item broken out by drug class in every reporting cycle.",
      a: { status: "In Progress", detail: "Reporting template change scheduled for next quarter's release." },
    },
  ],
  CLM: [
    {
      d: "A sample of adjudicated claims shows copay calculated against list price rather than the contracted discounted rate.",
      r: "Re-run affected claims through the correct pricing table and issue member refunds where owed.",
      a: { status: "Resolved", detail: "Affected claims reprocessed; member refunds issued." },
    },
  ],
  RPT: [
    {
      d: "Annual transparency report omits generic dispensing rate broken out by channel as required.",
      r: "Extend the reporting template to include channel-level generic dispensing metrics.",
      a: { status: "Not Started", detail: "Awaiting data warehouse access to build the new metric." },
    },
    {
      d: "Reporting cadence in practice runs 45 days behind the contractual submission deadline.",
      r: "Automate report generation from the claims warehouse to close the timing gap.",
      a: { status: "In Progress", detail: "Automation pipeline in build; target go-live next cycle." },
    },
  ],
  AUD: [
    {
      d: "Contract limits sponsor audit scope to a 12-month lookback despite a 3-year record retention obligation.",
      r: "Extend audit lookback rights to match the retention period stated in the reference standard.",
      a: { status: "Escalated", detail: "Sent to legal for contract amendment ahead of next renewal." },
    },
  ],
};

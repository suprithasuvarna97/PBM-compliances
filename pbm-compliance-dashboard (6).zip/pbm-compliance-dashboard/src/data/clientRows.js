// Dummy data for the Client View tab. In the real system this would come
// from the same review pipeline as Vendor View, keyed by client instead of
// vendor contract. Shaped to mirror buildVendorRows() output.

export const CLIENT_ROWS = [
  {
    id: "cl-1",
    clientName: "Acme Industries",
    contractLabel: "Acme Industries — Employer Group Rx Benefit Contract",
    accountManager: "Priya Nair",
    risk: "Moderate",
    complianceScore: 82,
    findings: { High: 0, Moderate: 3, Low: 5 },
  },
  {
    id: "cl-2",
    clientName: "Meridian Health",
    contractLabel: "Meridian Health — PBM Master Services Agreement (FY26)",
    accountManager: "James O'Connell",
    risk: "Low",
    complianceScore: 94,
    findings: { High: 0, Moderate: 1, Low: 2 },
  },
  {
    id: "cl-3",
    clientName: "Horizon Rx Network",
    contractLabel: "Horizon Rx Network — Pharmacy Services Contract",
    accountManager: "Dana Whitfield",
    risk: "High",
    complianceScore: 61,
    findings: { High: 2, Moderate: 4, Low: 3 },
  },
  {
    id: "cl-4",
    clientName: "State DHHS Medicaid Program",
    contractLabel: "Statewide Medicaid PBM Agreement — Dept. of Health & Human Services",
    accountManager: "Priya Nair",
    risk: "Moderate",
    complianceScore: 77,
    findings: { High: 0, Moderate: 2, Low: 6 },
  },
  {
    id: "cl-5",
    clientName: "Northgate School District",
    contractLabel: "Northgate School District — Group Health & Rx Plan",
    accountManager: "James O'Connell",
    risk: "Low",
    complianceScore: 91,
    findings: { High: 0, Moderate: 0, Low: 2 },
  },
];

import { useMemo, useState } from "react";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableCell from "@mui/material/TableCell";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Chip from "@mui/material/Chip";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";
import ToggleButton from "@mui/material/ToggleButton";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import DescriptionRoundedIcon from "@mui/icons-material/DescriptionRounded";
import { LICENSE_ROWS } from "../data/licenseRows";

const PARTY_TYPES = ["All", "Vendor", "Client"];

const STATUS_COLORS = {
  Active: { fg: "#2A6B4A", bg: "#E4F3EA" },
  "Renewal Due": { fg: "#8A5A16", bg: "#FBEDD8" },
  "Expiring Soon": { fg: "#B3432F", bg: "#FBE3DE" },
  Expired: { fg: "#8A1F1F", bg: "#F6DCDC" },
};

// License & Contract Status: tracks per-entity licensing/registration
// state across both vendors and clients. Data below is dummy/placeholder —
// wire this up to a real licensing feed later. The Vendor/Client filter
// reads each row's `partyType` field.
export default function LicenseStatus() {
  const allRows = LICENSE_ROWS;

  const [partyFilter, setPartyFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [stateFilter, setStateFilter] = useState("All");
  const [query, setQuery] = useState("");

  const statuses = useMemo(() => Array.from(new Set(allRows.map((r) => r.status))).sort(), [allRows]);
  const states = useMemo(() => Array.from(new Set(allRows.map((r) => r.state))).sort(), [allRows]);

  const rows = useMemo(() => {
    return allRows.filter((row) => {
      const matchesParty = partyFilter === "All" || row.partyType === partyFilter;
      const matchesStatus = statusFilter === "All" || row.status === statusFilter;
      const matchesState = stateFilter === "All" || row.state === stateFilter;
      const q = query.trim().toLowerCase();
      const matchesQuery =
        !q ||
        row.entity.toLowerCase().includes(q) ||
        row.licenseType.toLowerCase().includes(q) ||
        row.licenseNumber.toLowerCase().includes(q);
      return matchesParty && matchesStatus && matchesState && matchesQuery;
    });
  }, [allRows, partyFilter, statusFilter, stateFilter, query]);

  return (
    <Box>
      <Typography sx={{ fontSize: 11.5, color: "#8992A1", mb: 1.5 }}>
        Placeholder data — licensing feed not yet wired up.
      </Typography>

      <Box sx={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 1.5, mb: 1.25 }}>
        <ToggleButtonGroup exclusive size="small" value={partyFilter} onChange={(e, val) => val && setPartyFilter(val)}>
          {PARTY_TYPES.map((p) => (
            <ToggleButton key={p} value={p} sx={{ textTransform: "none", fontSize: 12.5, px: 1.75 }}>
              {p}
            </ToggleButton>
          ))}
        </ToggleButtonGroup>

        <TextField
          size="small"
          placeholder="Search entity, license type, or number"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          sx={{ minWidth: 280, bgcolor: "background.paper" }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchRoundedIcon sx={{ fontSize: 18, color: "#8992A1" }} />
              </InputAdornment>
            ),
          }}
        />
      </Box>

      <Box sx={{ display: "flex", gap: 1.5, mb: 1.75, flexWrap: "wrap" }}>
        <FormControl size="small" sx={{ minWidth: 180 }}>
          <InputLabel sx={{ fontSize: 12.5 }}>Status</InputLabel>
          <Select
            label="Status"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            sx={{ fontSize: 12.5, bgcolor: "background.paper" }}
          >
            <MenuItem value="All" sx={{ fontSize: 12.5 }}>
              All statuses
            </MenuItem>
            {statuses.map((s) => (
              <MenuItem key={s} value={s} sx={{ fontSize: 12.5 }}>
                {s}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        <FormControl size="small" sx={{ minWidth: 140 }}>
          <InputLabel sx={{ fontSize: 12.5 }}>State</InputLabel>
          <Select
            label="State"
            value={stateFilter}
            onChange={(e) => setStateFilter(e.target.value)}
            sx={{ fontSize: 12.5, bgcolor: "background.paper" }}
          >
            <MenuItem value="All" sx={{ fontSize: 12.5 }}>
              All states
            </MenuItem>
            {states.map((s) => (
              <MenuItem key={s} value={s} sx={{ fontSize: 12.5 }}>
                {s}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Box>

      <TableContainer component={Paper} variant="outlined">
        <Table size="small">
          <TableHead>
            <TableRow sx={{ "& th": { bgcolor: "#FAFBFC", fontSize: 11, color: "text.secondary", fontWeight: 500 } }}>
              <TableCell>Entity</TableCell>
              <TableCell>State</TableCell>
              <TableCell>License Type</TableCell>
              <TableCell>License Number</TableCell>
              <TableCell>Expiration Date</TableCell>
              <TableCell>Days Remaining</TableCell>
              <TableCell>Renewal Owner</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Documents</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.length === 0 ? (
              <TableRow>
                <TableCell colSpan={9} align="center" sx={{ py: 5, color: "#8992A1" }}>
                  No records match the current filter.
                </TableCell>
              </TableRow>
            ) : (
              rows.map((row) => (
                <TableRow key={row.id} hover>
                  <TableCell sx={{ fontWeight: 500, fontSize: 12.5 }}>
                    {row.entity}
                    <Typography component="div" sx={{ fontSize: 10.5, color: "#8992A1" }}>
                      {row.partyType}
                    </Typography>
                  </TableCell>
                  <TableCell sx={{ fontSize: 12.5 }}>{row.state}</TableCell>
                  <TableCell sx={{ fontSize: 12.5, color: "text.secondary" }}>{row.licenseType}</TableCell>
                  <TableCell sx={{ fontSize: 12.5 }}>{row.licenseNumber}</TableCell>
                  <TableCell sx={{ fontSize: 12.5 }}>{row.expirationDate}</TableCell>
                  <TableCell
                    sx={{
                      fontSize: 12.5,
                      fontWeight: 600,
                      color: row.daysRemaining < 0 ? "#B3432F" : row.daysRemaining <= 30 ? "#B8842E" : "text.primary",
                    }}
                  >
                    {row.daysRemaining < 0 ? `${Math.abs(row.daysRemaining)} overdue` : row.daysRemaining}
                  </TableCell>
                  <TableCell sx={{ fontSize: 12.5 }}>{row.renewalOwner}</TableCell>
                  <TableCell>
                    <Chip
                      size="small"
                      label={row.status}
                      sx={{
                        color: STATUS_COLORS[row.status]?.fg,
                        backgroundColor: STATUS_COLORS[row.status]?.bg,
                        fontSize: 11.5,
                      }}
                    />
                  </TableCell>
                  <TableCell>
                    <Button
                      size="small"
                      variant="outlined"
                      startIcon={<DescriptionRoundedIcon sx={{ fontSize: 15 }} />}
                      sx={{ fontSize: 12, py: 0.4, textTransform: "none" }}
                    >
                      {row.documents}
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {rows.length > 0 && (
        <Typography sx={{ fontSize: 11.5, color: "#8992A1", mt: 1.25 }}>
          Showing {rows.length} of {allRows.length} records
        </Typography>
      )}
    </Box>
  );
}

import { useMemo, useState } from "react";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableCell from "@mui/material/TableCell";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Tooltip from "@mui/material/Tooltip";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";
import ToggleButton from "@mui/material/ToggleButton";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import DescriptionRoundedIcon from "@mui/icons-material/DescriptionRounded";
import AuditFindingsBadge from "../components/AuditFindingsBadge";
import { buildVendorRows } from "../data/buildVendorRows";

const RISK_DOT = { High: "#B3432F", Moderate: "#B8842E", Low: "#3C7A5C" };
const RISK_LEVELS = ["All", "High", "Moderate", "Low"];

// Portfolio-level view: every vendor (contract) in the pool, each checked
// against the same regulations currently selected in the top bar — reads
// from the same matrix as Overview/Violation Log, so a vendor's numbers
// here always match what you'd see if you selected that contract there.
export default function VendorView({ vendors, regulations, matrix, onViewReport }) {
  const allRows = useMemo(() => buildVendorRows(vendors, regulations, matrix), [vendors, regulations, matrix]);

  const [riskFilter, setRiskFilter] = useState("All");
  const [departmentFilter, setDepartmentFilter] = useState("All");
  const [query, setQuery] = useState("");
  const [notifiedIds, setNotifiedIds] = useState(() => new Set());

  function handleNotify(id) {
    setNotifiedIds((prev) => {
      const next = new Set(prev);
      next.add(id);
      return next;
    });
  }

  const departments = useMemo(
    () => Array.from(new Set(allRows.map((r) => r.department))).sort(),
    [allRows]
  );

  const rows = useMemo(() => {
    return allRows.filter((row) => {
      const matchesRisk = riskFilter === "All" || row.risk === riskFilter;
      const matchesDept = departmentFilter === "All" || row.department === departmentFilter;
      const q = query.trim().toLowerCase();
      const matchesQuery =
        !q ||
        row.vendorName.toLowerCase().includes(q) ||
        row.contractLabel.toLowerCase().includes(q) ||
        row.department.toLowerCase().includes(q);
      return matchesRisk && matchesDept && matchesQuery;
    });
  }, [allRows, riskFilter, departmentFilter, query]);

  const regulationLabel = regulations.length
    ? regulations.map((r) => r.label.split("(")[0].trim()).join(", ")
    : "none selected";

  return (
    <Box>
      <Typography sx={{ fontSize: 11.5, color: "#8992A1", mb: 1.5 }}>
        Each vendor's contract checked against: {regulationLabel}
      </Typography>

      <Box sx={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 1.5, mb: 1.25 }}>
        <ToggleButtonGroup exclusive size="small" value={riskFilter} onChange={(e, val) => val && setRiskFilter(val)}>
          {RISK_LEVELS.map((lvl) => (
            <ToggleButton key={lvl} value={lvl} sx={{ textTransform: "none", fontSize: 12.5, px: 1.75 }}>
              {lvl}
            </ToggleButton>
          ))}
        </ToggleButtonGroup>

        <TextField
          size="small"
          placeholder="Search vendor, contract, or department"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          sx={{ minWidth: 280, bgcolor: "background.paper" }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchRoundedIcon sx={{ fontSize: 18, color: "#8992A1" }} />
              </InputAdornment>
            ),
          }}
        />
      </Box>

      <Box sx={{ display: "flex", gap: 1.5, mb: 1.75, flexWrap: "wrap" }}>
        <FormControl size="small" sx={{ minWidth: 220 }}>
          <Select
            value={departmentFilter}
            onChange={(e) => setDepartmentFilter(e.target.value)}
            sx={{ fontSize: 12.5, bgcolor: "background.paper" }}
          >
            <MenuItem value="All" sx={{ fontSize: 12.5 }}>
              All departments
            </MenuItem>
            {departments.map((d) => (
              <MenuItem key={d} value={d} sx={{ fontSize: 12.5 }}>
                {d}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Box>

      <TableContainer component={Paper} variant="outlined">
        <Table size="small">
          <TableHead>
            <TableRow sx={{ "& th": { bgcolor: "#FAFBFC", fontSize: 11, color: "text.secondary", fontWeight: 500 } }}>
              <TableCell>Vendor Name</TableCell>
              <TableCell>Contract</TableCell>
              <TableCell>Department</TableCell>
              <TableCell>Report</TableCell>
              <TableCell>Compliance Score</TableCell>
              <TableCell>Audit Findings</TableCell>
              <TableCell>Notify</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} align="center" sx={{ py: 5, color: "#8992A1" }}>
                  {allRows.length === 0
                    ? "No vendors in the pool yet — add a contract from the top bar."
                    : "No vendors match the current filter."}
                </TableCell>
              </TableRow>
            ) : (
              rows.map((row) => (
                <TableRow key={row.id} hover>
                  <TableCell sx={{ fontWeight: 500, fontSize: 12.5 }}>{row.vendorName}</TableCell>
                  <TableCell sx={{ fontSize: 12.5, color: "text.secondary", maxWidth: 260 }}>
                    {row.contractLabel}
                  </TableCell>
                  <TableCell sx={{ fontSize: 12.5 }}>{row.department}</TableCell>
                  <TableCell>
                    <Tooltip title={row.reviewed ? `Risk: ${row.risk}` : "Run a review to generate this vendor's report"}>
                      <span>
                        <Button
                          size="small"
                          variant="outlined"
                          disabled={!row.reviewed}
                          onClick={() => onViewReport(row)}
                          startIcon={
                            <DescriptionRoundedIcon
                              sx={{ fontSize: 15, color: row.reviewed ? RISK_DOT[row.risk] : undefined }}
                            />
                          }
                          sx={{ fontSize: 12, py: 0.4 }}
                        >
                          View Report
                        </Button>
                      </span>
                    </Tooltip>
                  </TableCell>
                  <TableCell sx={{ fontSize: 12.5, fontWeight: 600 }}>
                    {row.complianceScore != null ? `${row.complianceScore}%` : "—"}
                  </TableCell>
                  <TableCell>
                    <AuditFindingsBadge findings={row.reviewed ? row.findings : null} />
                  </TableCell>
                  <TableCell>
                    <Button
                      size="small"
                      variant={notifiedIds.has(row.id) ? "text" : "outlined"}
                      disabled={notifiedIds.has(row.id)}
                      onClick={() => handleNotify(row.id)}
                      sx={{
                        fontSize: 12,
                        py: 0.4,
                        color: notifiedIds.has(row.id) ? "#3C7A5C" : undefined,
                        textTransform: "none",
                      }}
                    >
                      {notifiedIds.has(row.id) ? "Notified" : "Notify"}
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {rows.length > 0 && (
        <Typography sx={{ fontSize: 11.5, color: "#8992A1", mt: 1.25 }}>
          Showing {rows.length} of {allRows.length} vendors
        </Typography>
      )}
    </Box>
  );
}

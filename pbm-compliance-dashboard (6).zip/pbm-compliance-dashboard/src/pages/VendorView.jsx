import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableCell from "@mui/material/TableCell";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import Typography from "@mui/material/Typography";
import RiskBadge from "../components/RiskBadge";
import AuditFindingsBadge from "../components/AuditFindingsBadge";
import { buildVendorRows } from "../data/buildVendorRows";

// Portfolio-level view: every vendor (contract) in the pool, each checked
// against the same regulations currently selected in the top bar — reads
// from the same matrix as Overview/Violation Log, so a vendor's numbers
// here always match what you'd see if you selected that contract there.
export default function VendorView({ vendors, regulations, matrix }) {
  const rows = buildVendorRows(vendors, regulations, matrix);
  const regulationLabel = regulations.length
    ? regulations.map((r) => r.label.split("(")[0].trim()).join(", ")
    : "none selected";

  return (
    <Box>
      <Typography sx={{ fontSize: 11.5, color: "#8992A1", mb: 1.5 }}>
        Each vendor's contract checked against: {regulationLabel}
      </Typography>

      <TableContainer component={Paper} variant="outlined">
        <Table size="small">
          <TableHead>
            <TableRow sx={{ "& th": { bgcolor: "#FAFBFC", fontSize: 11, color: "text.secondary", fontWeight: 500 } }}>
              <TableCell>Vendor Name</TableCell>
              <TableCell>Contract</TableCell>
              <TableCell>Department</TableCell>
              <TableCell>Risk</TableCell>
              <TableCell>Compliance Score</TableCell>
              <TableCell>Audit Findings</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} align="center" sx={{ py: 5, color: "#8992A1" }}>
                  No vendors in the pool yet — add a contract from the top bar.
                </TableCell>
              </TableRow>
            ) : (
              rows.map((row) => (
                <TableRow key={row.id} hover>
                  <TableCell sx={{ fontWeight: 500, fontSize: 12.5 }}>{row.vendorName}</TableCell>
                  <TableCell sx={{ fontSize: 12.5, color: "text.secondary", maxWidth: 260 }}>
                    {row.contractLabel}
                  </TableCell>
                  <TableCell sx={{ fontSize: 12.5 }}>{row.department}</TableCell>
                  <TableCell>
                    {row.risk ? (
                      <RiskBadge level={row.risk} />
                    ) : (
                      <Box component="span" sx={{ fontSize: 12, color: "#8992A1" }}>
                        —
                      </Box>
                    )}
                  </TableCell>
                  <TableCell sx={{ fontSize: 12.5, fontWeight: 600 }}>
                    {row.complianceScore != null ? `${row.complianceScore}%` : "—"}
                  </TableCell>
                  <TableCell>
                    <AuditFindingsBadge findings={row.reviewed ? row.findings : null} />
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
}

import { useMemo, useState } from "react";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableCell from "@mui/material/TableCell";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";
import ToggleButton from "@mui/material/ToggleButton";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Typography from "@mui/material/Typography";
import Link from "@mui/material/Link";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import OpenInNewRoundedIcon from "@mui/icons-material/OpenInNewRounded";
import RiskBadge from "../components/RiskBadge";
import ActionStatusChip from "../components/ActionStatusChip";

const RISK_LEVELS = ["All", "High", "Moderate", "Low"];

// Flattens the active contract's results across every selected regulation
// into one row-per-finding list — this is "Option A": one contract,
// multiple regulations checked together, so every regulation it was
// checked against shows up here, filterable by which one.
function flattenForContract(contracts, regulations, matrix) {
  const rows = [];
  contracts.forEach((c) => {
    regulations.forEach((r) => {
      const result = matrix[c.id]?.[r.id];
      if (!result) return;
      result.violations.forEach((v) => {
        rows.push({ ...v, regulationId: r.id, regulationLabel: r.label });
      });
    });
  });
  return rows;
}

export default function ViolationLog({ contracts, regulations, matrix }) {
  const [riskFilter, setRiskFilter] = useState("All");
  const [regulationFilter, setRegulationFilter] = useState("All");
  const [query, setQuery] = useState("");

  const allRows = useMemo(() => flattenForContract(contracts, regulations, matrix), [contracts, regulations, matrix]);

  const filtered = useMemo(() => {
    return allRows.filter((v) => {
      const matchesRisk = riskFilter === "All" || v.risk === riskFilter;
      const matchesRegulation = regulationFilter === "All" || v.regulationId === regulationFilter;
      const q = query.trim().toLowerCase();
      const matchesQuery =
        !q ||
        v.id.toLowerCase().includes(q) ||
        v.category.toLowerCase().includes(q) ||
        v.description.toLowerCase().includes(q);
      return matchesRisk && matchesRegulation && matchesQuery;
    });
  }, [allRows, riskFilter, regulationFilter, query]);

  return (
    <Box>
      <Box sx={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 1.5, mb: 1.25 }}>
        <ToggleButtonGroup exclusive size="small" value={riskFilter} onChange={(e, val) => val && setRiskFilter(val)}>
          {RISK_LEVELS.map((lvl) => (
            <ToggleButton key={lvl} value={lvl} sx={{ textTransform: "none", fontSize: 12.5, px: 1.75 }}>
              {lvl}
            </ToggleButton>
          ))}
        </ToggleButtonGroup>

        <TextField
          size="small"
          placeholder="Search rule ID, category, or description"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          sx={{ minWidth: 280, bgcolor: "background.paper" }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchRoundedIcon sx={{ fontSize: 18, color: "#8992A1" }} />
              </InputAdornment>
            ),
          }}
        />
      </Box>

      <Box sx={{ display: "flex", gap: 1.5, mb: 1.75, flexWrap: "wrap" }}>
        <FormControl size="small" sx={{ minWidth: 240 }}>
          <Select
            value={regulationFilter}
            onChange={(e) => setRegulationFilter(e.target.value)}
            sx={{ fontSize: 12.5, bgcolor: "background.paper" }}
          >
            <MenuItem value="All" sx={{ fontSize: 12.5 }}>
              All regulations
            </MenuItem>
            {regulations.map((r) => (
              <MenuItem key={r.id} value={r.id} sx={{ fontSize: 12.5 }}>
                {r.label}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Box>

      <TableContainer component={Paper} variant="outlined">
        <Table size="small">
          <TableHead>
            <TableRow sx={{ "& th": { bgcolor: "#FAFBFC", fontSize: 11, color: "text.secondary", fontWeight: 500 } }}>
              <TableCell>Rule ID</TableCell>
              <TableCell>Category</TableCell>
              <TableCell>Contract Clause</TableCell>
              <TableCell>Regulatory Reference</TableCell>
              <TableCell>Risk</TableCell>
              <TableCell>Finding</TableCell>
              <TableCell>Recommended Action</TableCell>
              <TableCell>Action Taken</TableCell>
              <TableCell>Reference Link</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={9} align="center" sx={{ py: 5, color: "#8992A1" }}>
                  No findings match the current filter.
                </TableCell>
              </TableRow>
            ) : (
              filtered.map((v) => (
                <TableRow key={`${v.regulationId}-${v.id}`} hover>
                  <TableCell sx={{ fontWeight: 500, whiteSpace: "nowrap" }}>{v.id}</TableCell>
                  <TableCell sx={{ fontSize: 12.5 }}>{v.category}</TableCell>
                  <TableCell sx={{ fontSize: 12.5, color: "text.secondary", whiteSpace: "nowrap" }}>{v.clause}</TableCell>
                  <TableCell sx={{ fontSize: 12.5, color: "text.secondary", whiteSpace: "nowrap" }}>{v.regClause}</TableCell>
                  <TableCell>
                    <RiskBadge level={v.risk} />
                  </TableCell>
                  <TableCell sx={{ fontSize: 12.5, maxWidth: 280, lineHeight: 1.45 }}>{v.description}</TableCell>
                  <TableCell sx={{ fontSize: 12.5, maxWidth: 240, lineHeight: 1.45, color: "text.secondary" }}>
                    {v.recommendation}
                  </TableCell>
                  <TableCell sx={{ maxWidth: 220 }}>
                    <ActionStatusChip actionTaken={v.actionTaken} />
                  </TableCell>
                  <TableCell sx={{ whiteSpace: "nowrap" }}>
                    {v.referenceLink ? (
                      <Link
                        href={v.referenceLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        sx={{ display: "inline-flex", alignItems: "center", gap: 0.4, fontSize: 12.5 }}
                      >
                        View source
                        <OpenInNewRoundedIcon sx={{ fontSize: 13 }} />
                      </Link>
                    ) : (
                      <Box component="span" sx={{ fontSize: 12, color: "#8992A1" }}>
                        Internal doc — no public link
                      </Box>
                    )}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {filtered.length > 0 && (
        <Typography sx={{ fontSize: 11.5, color: "#8992A1", mt: 1.25 }}>
          Showing {filtered.length} of {allRows.length} findings
        </Typography>
      )}
    </Box>
  );
}

import { useMemo, useState } from "react";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableCell from "@mui/material/TableCell";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";
import ToggleButton from "@mui/material/ToggleButton";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import AuditFindingsBadge from "../components/AuditFindingsBadge";
import { CLIENT_ROWS } from "../data/clientRows";

const RISK_LEVELS = ["All", "High", "Moderate", "Low"];

// Client-facing counterpart to Vendor View. Data here is dummy/placeholder
// for now — wire this up to a real client review pipeline later, mirroring
// how buildVendorRows() reads from the shared matrix.
export default function ClientView() {
  const allRows = CLIENT_ROWS;

  const [riskFilter, setRiskFilter] = useState("All");
  const [managerFilter, setManagerFilter] = useState("All");
  const [query, setQuery] = useState("");
  const [notifiedIds, setNotifiedIds] = useState(() => new Set());

  function handleNotify(id) {
    setNotifiedIds((prev) => {
      const next = new Set(prev);
      next.add(id);
      return next;
    });
  }

  const managers = useMemo(
    () => Array.from(new Set(allRows.map((r) => r.accountManager))).sort(),
    [allRows]
  );

  const rows = useMemo(() => {
    return allRows.filter((row) => {
      const matchesRisk = riskFilter === "All" || row.risk === riskFilter;
      const matchesManager = managerFilter === "All" || row.accountManager === managerFilter;
      const q = query.trim().toLowerCase();
      const matchesQuery =
        !q ||
        row.clientName.toLowerCase().includes(q) ||
        row.contractLabel.toLowerCase().includes(q) ||
        row.accountManager.toLowerCase().includes(q);
      return matchesRisk && matchesManager && matchesQuery;
    });
  }, [allRows, riskFilter, managerFilter, query]);

  return (
    <Box>
      <Typography sx={{ fontSize: 11.5, color: "#8992A1", mb: 1.5 }}>
        Placeholder data — client review pipeline not yet wired up.
      </Typography>

      <Box sx={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 1.5, mb: 1.25 }}>
        <ToggleButtonGroup exclusive size="small" value={riskFilter} onChange={(e, val) => val && setRiskFilter(val)}>
          {RISK_LEVELS.map((lvl) => (
            <ToggleButton key={lvl} value={lvl} sx={{ textTransform: "none", fontSize: 12.5, px: 1.75 }}>
              {lvl}
            </ToggleButton>
          ))}
        </ToggleButtonGroup>

        <TextField
          size="small"
          placeholder="Search client, contract, or account manager"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          sx={{ minWidth: 280, bgcolor: "background.paper" }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchRoundedIcon sx={{ fontSize: 18, color: "#8992A1" }} />
              </InputAdornment>
            ),
          }}
        />
      </Box>

      <Box sx={{ display: "flex", gap: 1.5, mb: 1.75, flexWrap: "wrap" }}>
        <FormControl size="small" sx={{ minWidth: 220 }}>
          <Select
            value={managerFilter}
            onChange={(e) => setManagerFilter(e.target.value)}
            sx={{ fontSize: 12.5, bgcolor: "background.paper" }}
          >
            <MenuItem value="All" sx={{ fontSize: 12.5 }}>
              All account managers
            </MenuItem>
            {managers.map((m) => (
              <MenuItem key={m} value={m} sx={{ fontSize: 12.5 }}>
                {m}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Box>

      <TableContainer component={Paper} variant="outlined">
        <Table size="small">
          <TableHead>
            <TableRow sx={{ "& th": { bgcolor: "#FAFBFC", fontSize: 11, color: "text.secondary", fontWeight: 500 } }}>
              <TableCell>Client Name</TableCell>
              <TableCell>Contract</TableCell>
              <TableCell>Account Manager</TableCell>
              <TableCell>Compliance Score</TableCell>
              <TableCell>Audit Findings</TableCell>
              <TableCell>Notify</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} align="center" sx={{ py: 5, color: "#8992A1" }}>
                  No clients match the current filter.
                </TableCell>
              </TableRow>
            ) : (
              rows.map((row) => (
                <TableRow key={row.id} hover>
                  <TableCell sx={{ fontWeight: 500, fontSize: 12.5 }}>{row.clientName}</TableCell>
                  <TableCell sx={{ fontSize: 12.5, color: "text.secondary", maxWidth: 260 }}>
                    {row.contractLabel}
                  </TableCell>
                  <TableCell sx={{ fontSize: 12.5 }}>{row.accountManager}</TableCell>
                  <TableCell sx={{ fontSize: 12.5, fontWeight: 600 }}>
                    {row.complianceScore != null ? `${row.complianceScore}%` : "—"}
                  </TableCell>
                  <TableCell>
                    <AuditFindingsBadge findings={row.findings} />
                  </TableCell>
                  <TableCell>
                    <Button
                      size="small"
                      variant={notifiedIds.has(row.id) ? "text" : "outlined"}
                      disabled={notifiedIds.has(row.id)}
                      onClick={() => handleNotify(row.id)}
                      sx={{
                        fontSize: 12,
                        py: 0.4,
                        color: notifiedIds.has(row.id) ? "#3C7A5C" : undefined,
                        textTransform: "none",
                      }}
                    >
                      {notifiedIds.has(row.id) ? "Notified" : "Notify"}
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {rows.length > 0 && (
        <Typography sx={{ fontSize: 11.5, color: "#8992A1", mt: 1.25 }}>
          Showing {rows.length} of {allRows.length} clients
        </Typography>
      )}
    </Box>
  );
}

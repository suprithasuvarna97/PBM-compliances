# Sentinel Rx — PBM Compliance Review Dashboard

A React + Material UI dashboard for reviewing **one contract against
multiple regulations, checked together** ("Option A"), plus a portfolio-
level Vendor View across every contract in the pool. No backend is wired
up yet — everything is generated client-side so the UI can be built and
demoed end to end.

## Project structure

```
sentinel-rx/
├─ index.html
├─ vite.config.js
├─ package.json
└─ src/
   ├─ main.jsx                    # React root, MUI ThemeProvider
   ├─ App.jsx                     # Owns selection + the shared matrix, layout, dialogs
   ├─ theme.js                    # MUI theme: palette, risk + status colors
   ├─ data/
   │  ├─ catalog.js                # Dropdown options, vendor metadata, regulation links, finding templates
   │  ├─ generateAnalysis.js       # Mock "LLM" output for one contract × one regulation
   │  ├─ generateContractText.js   # Synthetic full contract text (for the document viewer)
   │  ├─ aggregateMatrix.js        # Sums/averages results across a set of pairs (Overview)
   │  └─ buildVendorRows.js        # Per-contract rollup across regulations (Vendor View)
   ├─ hooks/
   │  └─ useMatrixAnalysis.js      # THE data source — runs generateAnalysis for every contract × regulation pair
   ├─ components/
   │  ├─ Sidebar.jsx, TopBar.jsx
   │  ├─ DocSelect.jsx             # Single- or multi-select + upload (Contract uses single, Regulations uses multi)
   │  ├─ UploadsDialog.jsx         # "View Uploads" — uploaded docs ONLY, View button per contract
   │  ├─ DocumentViewerDialog.jsx  # Full contract text, green-highlighted broken clauses
   │  ├─ ComplianceHeatmap.jsx     # Score breakdown, one row (contract) × N columns (regulations)
   │  ├─ KpiCard.jsx, RiskBadge.jsx, ActionStatusChip.jsx, AuditFindingsBadge.jsx
   │  └─ charts/ (RiskDonutChart, CategoryBarChart, TrendLineChart)
   └─ pages/
      ├─ Overview.jsx              # KPI cards + charts for the active contract vs. all selected regulations
      ├─ ViolationLog.jsx          # Every finding for the active contract, filterable by regulation/risk
      └─ VendorView.jsx            # Every contract in the pool, each vs. the same selected regulations
```

## Run it

```bash
npm install
npm run dev
```

Then open the URL Vite prints (usually `http://localhost:5173`).

## The data model ("Option A")

- **Contract**: single-select. One contract is "active" at a time.
- **Regulations**: multi-select. All selected regulations are checked
  **together** against the active contract.
- Clicking **Run Review** bumps `runNonce`. `useMatrixAnalysis` then runs
  `generateAnalysis()` for **every contract in the pool** (not just the
  active one) × every selected regulation, and stores it as
  `matrix[contractId][regulationId]`.
- **Overview** and **Violation Log** read `matrix` filtered to just the
  active contract, aggregated across the selected regulations.
- **Vendor View** reads the *same* `matrix`, but shows every contract's
  row — so a given contract's numbers are identical whether you're
  looking at it via Overview or via its row in Vendor View, because
  they're the same underlying data.
- The **document viewer** (opened from "View Uploads") also reads
  straight from `matrix[contractId]`, so it works for any contract in the
  pool, not just the currently active one.

This "one matrix, several views into it" design is what keeps everything
in sync — there's a single hook call in `App.jsx`, and every page is just
a different filter/aggregation over its result.

## Fixed: uploaded documents not appearing

The previous version used MUI `Autocomplete` for both pickers. After not
being able to find a logic bug through code review, and given
`Autocomplete`'s heavier reliance on object-identity comparisons (and
sensitivity to exact MUI minor-version behavior), it was replaced with
`DocSelect.jsx` — a single component built on a plain MUI `Select`
(`multiple` prop for Regulations, single value for Contract). Values are
always plain string ids, which removes an entire class of "why isn't this
showing up" bugs. If uploads still don't appear after this change, that
points to something more specific (e.g. a MUI version pulled by `npm
install` behaving differently) — let me know exactly what you see
(nothing added to the dropdown at all? added but not shown in "View
Uploads"? console errors?) and I can narrow it down further.

## The document viewer (green highlights)

There's no real PDF/DOCX text extraction wired up — an uploaded file
today is just a filename, its content is never read. `generateContractText.js`
builds a **synthetic** but structurally realistic contract (numbered
articles) and slots each violation's finding text into the article that
matches its category, flagging that paragraph as `broken: true`.
`DocumentViewerDialog` renders the full text and highlights those
paragraphs in green (per your original request — note this is the
opposite of the red/amber/green convention used elsewhere in the app; a
one-line color change in that file's `p.broken` style block switches it
to amber/red if that reads better next to the risk badges).

## Vendor View

Columns: **Vendor Name, Contract, Department, Risk, Compliance Score,
Audit Findings** (shown as `H:3  M:4  L:2`). Vendor name and department
come from `VENDOR_META` in `catalog.js` (falls back to the filename +
"Unassigned" for uploaded contracts without a catalog entry). Risk,
score, and audit findings are computed by `buildVendorRows.js` from the
same `matrix` every other page reads — nothing here is independently
randomized.

## Wiring up a real backend later

Replace the body of the `useEffect` in `src/hooks/useMatrixAnalysis.js`
with a real API call (per pair, or one batched call returning the whole
matrix). As long as each result has the same shape as `generateAnalysis()`
returns (`totalClauses`, `violations[]`, `riskCounts`, `categoryBreakdown`,
`complianceScore`, `trend`, `timestamp`), nothing else in the app needs to
change — Overview, Violation Log, Vendor View, and the document viewer all
consume that same shape through `aggregateMatrix.js` / `buildVendorRows.js`.
